import test from 'node:test';
import assert from 'node:assert/strict';
import { isStockAuthError } from '../src/stock.mjs';

test('stock OAuth refresh recognizes provider authentication failures', () => {
  for (const message of ['HTTP 401', 'HTTP 403', 'invalid_token', 'invalid token', 'Authentication required', 'Unauthorized']) assert.equal(isStockAuthError(new Error(message)), true, message);
  for (const message of ['quota exhausted', 'rate limit', 'network timeout']) assert.equal(isStockAuthError(new Error(message)), false, message);
});
