import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { resultStore, visibleResult, RESULT_MAX_AGE_MS } from '../src/connection-results.mjs';
process.env.AIAGENT_CONNECTION_RESULTS_DIR = await mkdtemp(join(tmpdir(), 'aiagent-result-tests-'));
const { connectionState } = await import('../src/connection-tests.mjs');
import { customQwenOptions } from '../src/model-options.mjs';
import { page } from '../src/ui.mjs';

test('Qwen workspace addresses and backward compatibility', () => {
  for (const region of ['cn-beijing', 'ap-southeast-1']) assert.equal(customQwenOptions({ custom_qwen_region: region, custom_qwen_workspace_id: 'workspace123' }).baseUrl, `https://workspace123.${region}.maas.aliyuncs.com`);
  assert.equal(customQwenOptions({ custom_qwen_base_url: 'https://your-qwen-endpoint.example/api-ws/v1/realtime' }).baseUrl, 'https://your-qwen-endpoint.example');
  assert.throws(() => customQwenOptions({ custom_qwen_region: 'cn-beijing' }), /工作空间/);
  assert.throws(() => customQwenOptions({ custom_qwen_region: 'cn-beijing', custom_qwen_workspace_id: 'evil/path' }), /工作空间/);
});
test('generated browser script parses and includes all test controls', () => {
  const html = page();
  new Function(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
  assert.ok(html.includes('专属连接地址（自动生成）'));
  assert.ok(html.includes("card('notification'"));
  assert.ok(html.includes('modelConnectionControls(saved)'));
});
test('actual authentication, permission check, cache invalidation and tenant separation', async () => {
  const original = globalThis.fetch;
  let calls = 0;
  const draft = { threecx_server: 'https://pbx.example.test', intake_client_id: 'YOUR_ANALYSIS_CLIENT_ID', analysis_api_key: 'test-secret' };
  globalThis.fetch = async (url, options) => {
    calls++;
    assert.equal(options.redirect, 'error');
    if (url.endsWith('/connect/token')) return Response.json({ access_token: 'fake-token' });
    assert.equal(options.headers.Authorization, 'Bearer fake-token');
    return Response.json([{ dn: 'YOUR_ANALYSIS_CLIENT_ID' }]);
  };
  try {
    assert.equal((await connectionState('analysis','threecx','test-owner','test-space',{},false)).state,'empty');
    assert.equal((await connectionState('analysis','threecx','test-owner','test-space',draft,true)).state,'success');
    assert.equal(calls,2);
    assert.equal((await connectionState('analysis','threecx','test-owner','test-space',draft,false)).state,'success');
    assert.equal((await connectionState('analysis','threecx','other-owner','test-space',draft,false)).state,'untested');
    assert.equal((await connectionState('analysis','threecx','test-owner','test-space',{...draft,intake_client_id:'1973'},false)).state,'untested');
    assert.equal((await connectionState('analysis','notification','test-owner','test-space',draft,true)).state,'failed');
    globalThis.fetch=async()=>new Response('{}',{status:403});
    const failed=await connectionState('analysis','threecx','test-owner','test-space',draft,true);
    assert.equal(failed.state,'failed');assert.match(failed.message,/403/);assert.ok(!JSON.stringify(failed).includes('test-secret'));
  } finally {globalThis.fetch=original}
});
test('model must return valid output to become green', async () => {
  const original=globalThis.fetch;
  const draft={deepseek_config_mode:'custom',custom_deepseek_api_key:'fake',custom_deepseek_base_url:'https://model.example.test',custom_deepseek_model:'test-model'};
  try {
    globalThis.fetch=async()=>Response.json({});
    assert.equal((await connectionState('analysis','deepseek','tester','test-space',draft,true)).state,'failed');
    globalThis.fetch=async()=>Response.json({choices:[{message:{content:'OK'}}]});
    assert.equal((await connectionState('analysis','deepseek','tester','test-space',draft,true)).state,'success');
  }finally{globalThis.fetch=original}
});

test('expiry is gray/stale and preserves previous test outcome and timestamp', () => {
  const at=Date.now(),testedAt=new Date(at).toISOString();
  for(const state of ['success','failed']){
    const entry={fingerprint:'same',at,result:{state,message:'result',testedAt}};
    assert.equal(visibleResult(entry,'same',true,at+300001).state,state);
    const stale=visibleResult(entry,'same',true,at+RESULT_MAX_AGE_MS);
    assert.equal(stale.state,'stale');assert.equal(stale.lastState,state);assert.equal(stale.testedAt,testedAt);
    assert.equal(visibleResult(entry,'changed',true).state,'untested');
    assert.equal(visibleResult(entry,'same',false).state,'empty');
  }
});
test('fresh process restores result; storage contains no API key and uses private files', async () => {
  const store=resultStore();
  const key=JSON.stringify(['workspace','user','analysis','qwen']);
  await store.save(key,{fingerprint:'hash-only',at:Date.now(),result:{state:'success',message:'连接成功',testedAt:new Date().toISOString()}});
  const probe=spawnSync(process.execPath,['--input-type=module','-e',`import {resultStore} from ${JSON.stringify(new URL('../src/connection-results.mjs',import.meta.url).href)}; console.log(JSON.stringify(await resultStore().read(${JSON.stringify(key)})));`],{encoding:'utf8',env:process.env});
  assert.equal(probe.status,0,probe.stderr);assert.equal(JSON.parse(probe.stdout).result.state,'success');
  for(const name of await readdir(process.env.AIAGENT_CONNECTION_RESULTS_DIR)){
    const file=join(process.env.AIAGENT_CONNECTION_RESULTS_DIR,name);
    assert.equal((await stat(file)).mode&0o777,0o600);
    assert.ok(!(await readFile(file,'utf8')).includes('test-secret'));
  }
});
