import test from 'node:test';
import assert from 'node:assert/strict';
import { connectionOriginAllowed } from '../src/request-origin.mjs';

test('public browser origin works behind the reverse proxy', () => {
  assert.equal(connectionOriginAllowed('https://your-domain.example','127.0.0.1:YOUR_HTTP_PORT'),true);
  assert.equal(connectionOriginAllowed('https://your-domain.example','your-server.example:YOUR_HTTP_PORT'),true);
  assert.equal(connectionOriginAllowed('http://localhost:18185','localhost:18185'),true);
});
test('unrelated origins remain blocked', () => {
  for(const origin of ['https://evil.example','https://your-domain.example.evil.example','https://your-domain.example@evil.example','null','file:///','https://your-domain.example/path']) assert.equal(connectionOriginAllowed(origin,'127.0.0.1:YOUR_HTTP_PORT'),false,origin);
  assert.equal(connectionOriginAllowed('https://other.example','127.0.0.1:YOUR_HTTP_PORT','https://other.example'),true);
});
