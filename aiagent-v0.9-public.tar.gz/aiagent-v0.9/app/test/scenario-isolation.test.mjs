import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createScenario, scenarioIds } from '../src/scenarios/index.mjs';

function context(id, settings = {}) {
  return { settings, caller: { name: '客人', room: '666', number: '666' }, call: { id: 'call-test', transcript: [] }, userId: 'owner', welcomeLanguageText: '欢迎语使用普通话表达。', activeLanguage: () => 'mandarin' };
}

test('three business modules expose isolated contracts', () => {
  assert.deepEqual(scenarioIds, ['realtime', 'creation', 'analysis']);
  const realtime = createScenario('realtime', context('realtime', { mcp_provider: 'weather', welcome: '实时欢迎语' }));
  const creation = createScenario('creation', context('creation', { welcome: '创建欢迎语' }));
  const analysis = createScenario('analysis', context('analysis', { welcome: '分析欢迎语' }));
  assert.equal(realtime.greeting, '实时欢迎语');
  assert.equal(creation.greeting, '客人，您好，请问需要什么服务？');
  assert.equal(analysis.greeting, '分析欢迎语');
  assert.deepEqual(realtime.localTools.map(x => x.name), ['amap_weather']);
  assert.deepEqual(creation.localTools.map(x => x.name), ['hotel_create_order']);
  assert.deepEqual(analysis.localTools.map(x => x.name), ['create_analysis_task']);
});

test('changing one assistant settings cannot alter other assistant policy', () => {
  const realtimeBefore = createScenario('realtime', context('realtime', { welcome: 'R', prompt: 'RP' }));
  const analysisBefore = createScenario('analysis', context('analysis', { welcome: 'A', prompt: 'AP' }));
  const creation = createScenario('creation', context('creation', { welcome: '', prompt: '只修改语音创建' }));
  const realtimeAfter = createScenario('realtime', context('realtime', { welcome: 'R', prompt: 'RP' }));
  const analysisAfter = createScenario('analysis', context('analysis', { welcome: 'A', prompt: 'AP' }));
  assert.equal(realtimeAfter.greeting, realtimeBefore.greeting);
  assert.deepEqual(realtimeAfter.instructions, realtimeBefore.instructions);
  assert.deepEqual(realtimeAfter.localTools, realtimeBefore.localTools);
  assert.equal(analysisAfter.greeting, analysisBefore.greeting);
  assert.deepEqual(analysisAfter.instructions, analysisBefore.instructions);
  assert.ok(creation.instructions.includes('只修改语音创建'));
});

test('business modules do not import each other', async () => {
  for (const name of scenarioIds) {
    const source = await readFile(new URL(`../src/scenarios/${name}.mjs`, import.meta.url), 'utf8');
    for (const other of scenarioIds.filter(id => id !== name)) assert.doesNotMatch(source, new RegExp(`from ['\"].*\\/${other}\\.mjs`));
  }
});

test('each assistant owns a separate UI definition', async () => {
  const { scenarioUI } = await import('../src/scenarios/ui-index.mjs');
  assert.deepEqual(Object.keys(scenarioUI), scenarioIds);
  assert.ok('services' in scenarioUI.creation.sections);
  assert.ok(!('services' in scenarioUI.realtime.sections));
  assert.ok('model' in scenarioUI.analysis.sections);
  assert.ok(!('model' in scenarioUI.creation.sections));
  for (const name of scenarioIds) {
    const source = await readFile(new URL(`../src/scenarios/${name}-ui.mjs`, import.meta.url), 'utf8');
    for (const other of scenarioIds.filter(id => id !== name)) assert.doesNotMatch(source, new RegExp(`from ['\"].*\\/${other}-ui\\.mjs`));
  }
});

test('shared 3CX runtime contains no assistant tool or service policy', async () => {
  const source = await readFile(new URL('../src/threecx-runtime.mjs', import.meta.url), 'utf8');
  for (const businessTerm of ['hotel_create_order', 'create_analysis_task', 'GLOBAL_QUOTE', 'amap_weather', '服务项目不在目录']) assert.doesNotMatch(source, new RegExp(businessTerm));
  assert.match(source, /createScenario\(binding\.id/);
});

test('an assistant rejects tools owned by another assistant', async () => {
  const realtime = createScenario('realtime', context('realtime'));
  const creation = createScenario('creation', context('creation'));
  const analysis = createScenario('analysis', context('analysis'));
  assert.equal((await realtime.handleTool('hotel_create_order', '{}', {})).ok, false);
  assert.equal((await creation.handleTool('create_analysis_task', '{}')).ok, false);
  assert.equal((await analysis.handleTool('GLOBAL_QUOTE', '{}')).ok, false);
});
