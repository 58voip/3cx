import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, cp, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

test('new users do not inherit administrator 3CX settings', async () => {
  const root = await mkdtemp(join(tmpdir(), 'aiagent-tenant-'));
  await cp(new URL('../src/store.mjs', import.meta.url), join(root, 'store.mjs'));
  await cp(new URL('../src/model-options.mjs', import.meta.url), join(root, 'model-options.mjs'));
  const store = await import(pathToFileURL(join(root, 'store.mjs')) + `?t=${Date.now()}`);
  await store.updateSettings('realtime', { client_id: 'YOUR_REALTIME_CLIENT_ID', threecx_server: 'https://pbx.example', threecx_api_key: 'admin-secret' }, 'admin@example.com');
  const customer = await store.getSettings('realtime', 'customer@example.com');
  assert.equal(customer.client_id, undefined);
  assert.equal(customer.threecx_server, undefined);
  assert.equal(customer.threecx_api_key_configured, false);
});

test('3CX API IDs cannot be reused across users', async () => {
  const root = await mkdtemp(join(tmpdir(), 'aiagent-id-'));
  await cp(new URL('../src/store.mjs', import.meta.url), join(root, 'store.mjs'));
  await cp(new URL('../src/model-options.mjs', import.meta.url), join(root, 'model-options.mjs'));
  const store = await import(pathToFileURL(join(root, 'store.mjs')) + `?t=${Date.now()}`);
  await store.updateSettings('creation', { client_id: '3101' }, 'first@example.com');
  await assert.rejects(() => store.assertThreeCxIdsAvailable(['3101'], 'second@example.com'), /已被其他用户使用/);
  await assert.rejects(() => store.assertThreeCxIdsAvailable(['3102', '3102'], 'second@example.com'), /不能重复/);
});

test('self registration requires a phone number and remains pending', async () => {
  const root = await mkdtemp(join(tmpdir(), 'aiagent-register-'));
  for (const name of ['auth.mjs', 'email.mjs', 'store.mjs', 'model-options.mjs']) await cp(new URL(`../src/${name}`, import.meta.url), join(root, name));
  const auth = await import(pathToFileURL(join(root, 'auth.mjs')) + `?t=${Date.now()}`);
  const email = `guest-${Date.now()}@example.com`;
  await assert.rejects(() => auth.registerUser({ username: email, password: 'ExamplePass123' }), /手机号码/);
  const user = await auth.registerUser({ username: email, display_name: 'Guest', phone: '+86 13800138000', password: 'ExamplePass123' });
  assert.equal(user.pending_approval, true);
  assert.equal(user.active, false);
  assert.equal(await auth.login(email, 'ExamplePass123'), null);
  const approved = await auth.approveUser(email);
  assert.equal(approved.active, true);
  assert.equal(approved.pending_approval, false);
});
