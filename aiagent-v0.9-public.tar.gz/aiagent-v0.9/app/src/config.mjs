const realtimeUrl = process.env.AIAGENT_QWEN_ENDPOINT || 'https://your-qwen-endpoint.example/api-ws/v1/realtime';

export const qwenRealtime = {
  apiKey: process.env.AIAGENT_QWEN_API_KEY || '',
  endpoint: realtimeUrl,
  // The realtime bridge appends /api-ws/v1/realtime itself. Prefer the
  // migrated realtime endpoint's origin so an old HTTP-compatible base URL
  // cannot produce a 404 WebSocket path.
  baseUrl: process.env.AIAGENT_QWEN_BASE_URL || realtimeUrl.replace(/^wss?:\/\//, 'https://').replace(/\/api-ws\/v1\/realtime.*$/, ''),
  model: process.env.AIAGENT_QWEN_MODEL || 'qwen3.5-omni-plus-realtime',
  voice: process.env.AIAGENT_QWEN_VOICE || 'Tina',
  vadSilenceDurationMs: Number(process.env.AIAGENT_QWEN_VAD_MS || 0) || undefined,
  source: 'environment',
};

export function publicConfigStatus() {
  return { provider: 'qwen-realtime', model: qwenRealtime.model, voice: qwenRealtime.voice, endpoint: qwenRealtime.endpoint, configured: Boolean(qwenRealtime.apiKey), source: qwenRealtime.source, vadSilenceDurationMs: qwenRealtime.vadSilenceDurationMs ?? null };
}
