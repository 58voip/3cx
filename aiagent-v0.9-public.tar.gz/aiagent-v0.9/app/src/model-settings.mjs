import { qwenRealtime } from './config.mjs';
import { getSettings, getSecretSetting } from './store.mjs';
import { customQwenOptions } from './model-options.mjs';

export async function resolveQwen(scenario, userId, workspaceId = 'default') {
  const settings = await getSettings(scenario, userId, workspaceId);
  if (settings.qwen_config_mode !== 'custom') return { ...qwenRealtime };
  const apiKey = await getSecretSetting(scenario, 'custom_qwen_api_key', userId, workspaceId);
  if (!apiKey) throw new Error('请先在模型设置中保存 Qwen API Key');
  const options = customQwenOptions(settings);
  return { ...qwenRealtime, ...options, endpoint: options.baseUrl.replace(/^https:/, 'wss:') + '/api-ws/v1/realtime', apiKey, source: 'custom' };
}

export async function resolveDeepseek(userId, workspaceId = 'default') {
  const settings = await getSettings('analysis', userId, workspaceId);
  const name = settings.deepseek_config_mode === 'custom' ? 'custom_deepseek_api_key' : 'deepseek_api_key';
  let apiKey = await getSecretSetting('analysis', name, userId, workspaceId);
  if (!apiKey && settings.deepseek_config_mode !== 'custom') apiKey = await getSecretSetting('analysis', 'deepseek_api_key', userId, workspaceId);
  if (!apiKey) throw new Error(settings.deepseek_config_mode === 'custom' ? '请先在模型设置中保存 DeepSeek API Key' : 'DeepSeek 演示配置尚未配置');
  return apiKey;
}
