import { queryWeather } from '../weather.mjs';
import { queryStock } from '../stock.mjs';
import { knowledgeInstructions, parseToolArguments, unsupportedTool, welcomeRule } from './shared.mjs';

const weatherTool = { type: 'function', name: 'amap_weather', description: '查询中国城市的高德实时天气或未来天气预报。涉及天气、温度、降雨或天气预报时必须调用；必须先确认城市，不能凭记忆猜测。', parameters: { type: 'object', properties: { city: { type: 'string', description: '中国城市名称' }, forecast: { type: 'boolean', description: '是否查询未来天气预报，默认 false' } }, required: ['city'] } };
const stockTool = { type: 'function', name: 'GLOBAL_QUOTE', description: '查询股票实时行情。用户说出股票名称或代码时调用，不提供投资建议。', parameters: { type: 'object', properties: { symbol: { type: 'string', description: '股票名称或代码，可用逗号分隔多只' } }, required: ['symbol'] } };
const stockToolAlias = { ...stockTool, name: 'get_quote' };
function mcpMode(settings) { return String(settings.mcp_provider || (['true', 'on', '1', 'yes'].includes(String(settings.builtin_weather || '').toLowerCase()) ? 'weather' : 'custom')).toLowerCase(); }
function weatherEnabled(settings) { return mcpMode(settings) === 'weather' || ['true', 'on', '1', 'yes'].includes(String(settings.builtin_weather || '').toLowerCase()); }
function quotaReply(language) { return language === 'cantonese' ? '股票免費額度已用光，下一分鐘再查詢。' : language === 'english' ? 'The free stock quota is used up. Please try again next minute.' : '股票免费额度已用光，下一分钟再查询。'; }

export function createRealtimeScenario({ settings, userId, welcomeLanguageText }) {
  const useWeather = weatherEnabled(settings), useStock = mcpMode(settings) === 'stock';
  const [answerRule, soundRule, knowledgeRule] = knowledgeInstructions(settings);
  const instructions = [String(settings.prompt || '你是一个专业、自然、简洁的实时语音助手。'), answerRule, soundRule, welcomeRule(welcomeLanguageText), useWeather ? '【天气查询】涉及天气、温度、降雨、台风或天气预报时，必须调用 amap_weather 获取实时结果；必须先确认城市，禁止根据模型记忆猜测天气。' : '', useStock ? '【股票查询】用户询问股价或行情时调用 GLOBAL_QUOTE；支持中文名称和代码；只播报查询结果，不提供投资建议。' : '', knowledgeRule].filter(Boolean);
  return {
    id: 'realtime', greeting: String(settings.welcome || '您好，请问有什么可以帮您？'), instructions,
    localTools: useWeather ? [weatherTool] : (useStock ? [stockTool, stockToolAlias] : []),
    async handleTool(name, raw, context) {
      if (name === 'amap_weather' && useWeather) { try { const args = parseToolArguments(raw); return { ok: true, content: await queryWeather(args.city, args.forecast === true || args.forecast === 'true' || args.forecast === '是' || args.forecast === '预报') }; } catch (error) { return { ok: false, content: error.message || String(error) }; } }
      if ((name === 'GLOBAL_QUOTE' || name === 'get_quote') && useStock) { try { const args = parseToolArguments(raw); const language = context.activeLanguage() || (String(settings.welcome_language || 'auto') === 'yue' ? 'cantonese' : String(settings.welcome_language || '') === 'en' ? 'english' : 'mandarin'); let quotaNoticeShown = false; context.bridge().playWaitingMusic(800); return { ok: true, content: await queryStock(args.symbol, userId, 'default', (_duration, minuteLimit) => { context.bridge().playWaitingMusic(800); if (minuteLimit && !quotaNoticeShown) { quotaNoticeShown = true; context.bridge().speak(quotaReply(language)); } }) }; } catch (error) { if (error?.code === 'STOCK_DAILY_QUOTA') return { ok: false, content: quotaReply(context.activeLanguage() || 'mandarin') }; return { ok: false, content: error.message || String(error) }; } }
      return unsupportedTool();
    },
  };
}
