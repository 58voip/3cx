import { realtimeUI } from './realtime-ui.mjs';
import { creationUI } from './creation-ui.mjs';
import { analysisUI } from './analysis-ui.mjs';

export const scenarioUI = Object.freeze({ realtime: realtimeUI, creation: creationUI, analysis: analysisUI });
