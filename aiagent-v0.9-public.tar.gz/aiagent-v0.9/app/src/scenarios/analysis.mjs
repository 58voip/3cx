import { createTask } from '../store.mjs';
import { knowledgeInstructions, parseToolArguments, unsupportedTool, welcomeRule } from './shared.mjs';

const analysisTool = { type: 'function', name: 'create_analysis_task', description: '立刻创建后台语音分析任务。支持通话、系统安全、攻击异常、日志、IP 封锁、队列与人员等 3CX 只读分析。系统安全请求不需要分机，employee 和 department 留空。不得为了补充信息向来电者追问或确认。', parameters: { type: 'object', properties: { employee: { type: 'string', description: '分机号或人员；系统安全请求未说时留空' }, department: { type: 'string', description: '可留空' }, period: { type: 'string', description: '未说时填今天' }, analysisTarget: { type: 'string', description: '必须概括来电者请求的主题；安全请求填写 3CX安全分析、攻击异常分析或日志分析，未说时填通话内容总结' } }, required: ['analysisTarget'] } };
const rules = '【语音分析任务规则】只要来电者提出明确分析请求，就必须在本轮立即调用 create_analysis_task，绝不追问、复述或确认。只把来电者明确说出的分机号或姓名写入 employee；没说对象时 employee 必须留空，严禁猜测或虚构姓名。不要询问员工姓名或部门，department 留空即可。未说明时间填“今天”，未说明目标填“通话内容总结”。系统安全、攻击、异常、漏洞、日志、黑名单、封锁、IP 等请求同样是明确分析请求：必须立即创建任务，employee 留空，analysisTarget 明确填写“3CX安全分析”或对应主题；绝不能说无法查询，也不能要求提供员工或分机。不要在电话中直接分析或编造结论。严格禁止在未调用 create_analysis_task 且未收到工具成功结果前，说“好的”、任务已创建、会回拨或任何完成承诺；来电者说话像是未说完或请求不完整时保持安静，等待下一段语音。工具成功后只用来电者语言简短回复任务已创建。';

export function createAnalysisScenario({ settings, caller, call, userId, welcomeLanguageText, activeLanguage }) {
  const reply = String(settings.task_reply || '好的，已为您创建分析任务，完成后会回拨通知。').trim();
  const [answerRule, soundRule, knowledgeRule] = knowledgeInstructions(settings);
  return {
    id: 'analysis', greeting: String(settings.welcome || '您好，这里是语音分析助手，请告诉我需要分析的人员、时间范围和内容。'), vadSilenceDurationMs: 2400,
    instructions: [String(settings.prompt || '你是一个专业、自然、简洁的实时语音助手。'), rules, answerRule, soundRule, welcomeRule(welcomeLanguageText), knowledgeRule, '任务创建成功后的回复内容：' + reply + '。只在工具成功后回复一次，按来电语言自然翻译。'], localTools: [analysisTool],
    async handleTool(name, raw) {
      if (name !== 'create_analysis_task') return unsupportedTool();
      try { const args = parseToolArguments(raw); await createTask({ scenario: 'analysis', type: 'voice_analysis', title: String(args.analysisTarget || '语音分析任务').trim(), payload: { employee: String(args.employee || '').trim(), department: String(args.department || '').trim(), period: String(args.period || '今天').trim(), analysis_target: String(args.analysisTarget || '').trim(), language: activeLanguage() || 'mandarin', caller_name: caller.name, caller_number: caller.number, caller_extension: caller.room, source: 'voice', call_id: call.id }, user_id: userId, workspace_id: 'default' }); return { ok: true, content: '任务已创建。请用来电者语言只回复一次：' + reply + ' 不要询问、确认、复述，也不要说出任务编号。' }; } catch (error) { return { ok: false, content: error.message || String(error) }; }
    },
  };
}
