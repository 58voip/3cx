import { createTask } from '../store.mjs';
import { knowledgeInstructions, parseToolArguments, unsupportedTool, welcomeRule } from './shared.mjs';

const creationTool = { type: 'function', name: 'hotel_create_order', description: '创建客房服务任务。房间分机和客人姓名由系统从本次 3CX 来电自动带入，不要询问或覆盖；识别到服务项目和数量后立即调用。', parameters: { type: 'object', properties: { item: { type: 'string', description: '客人需要的服务项目，例如毛巾、矿泉水、牙刷' }, quantity: { type: 'integer', minimum: 1, maximum: 99, description: '数量，未说明时使用 1' } }, required: ['item'] } };
const serviceAliases = new Map([['矿泉水', ['水', '饮用水', '瓶装水', '纯净水', '冰水']], ['纸巾', ['面巾纸', '抽纸']], ['毛巾', ['小毛巾', '方巾', '面巾']], ['浴巾', ['大毛巾', '大浴巾']], ['牙刷', ['一次性牙刷', '洗漱牙刷']], ['牙膏', ['洗漱牙膏']], ['拖鞋', ['一次性拖鞋', '酒店拖鞋']], ['衣架', ['挂衣架', '衣服架']], ['枕头', ['枕芯', '靠枕']], ['洗发水', ['洗发露', '洗头水', '洗发液']], ['沐浴露', ['沐浴液', '沐浴乳', '洗澡液']], ['垃圾袋', ['塑料袋', '垃圾塑料袋']]]);
function normalizeService(value) { const input = String(value || '').toLowerCase().replace(/[\s　]/g, ''); for (const [name, aliases] of serviceAliases) if ([name, ...aliases].some(item => item.toLowerCase().replace(/[\s　]/g, '') === input)) return name; return String(value || '').trim(); }

export function createCreationScenario({ settings, caller, call, userId, welcomeLanguageText }) {
  const servicePrompts = `【服务内容语言提示】普通话：${settings.service_prompt_zh || '请说出您需要的服务项目和数量。'}\n粤语：${settings.service_prompt_yue || '請講出您需要嘅服務項目同數量。'}\n英语：${settings.service_prompt_en || 'Please tell me the service item and quantity you need.'}\n服务目录：${settings.catalog || '矿泉水、水、纸巾、毛巾、浴巾、牙刷、牙膏、拖鞋。'}`;
  const context = `【语音创建任务规则】这是任务创建助手。来电分机名就是房间号：${caller.room || '未读取到'}，绝对不要询问房间号。3CX 来电姓名是：${caller.name || '未识别'}；回复时优先直接称呼客人姓名。识别到服务项目和数量后，立即调用 hotel_create_order，不要向客人重复确认，不要等待客人确认。工具成功后，用客人的语言礼貌回复“好的，我马上安排”；只有工具返回成功才可以说任务已创建。服务项目不在目录时，说明暂不提供并建议转人工。`;
  const [answerRule, soundRule, knowledgeRule] = knowledgeInstructions(settings);
  return {
    id: 'creation', greeting: caller.name ? `${caller.name}，您好，请问需要什么服务？` : String(settings.welcome || '您好，请问需要什么服务？'),
    instructions: [servicePrompts, String(settings.prompt || '你是一个专业、自然、简洁的实时语音助手。'), context, answerRule, soundRule, welcomeRule(welcomeLanguageText), knowledgeRule], localTools: [creationTool],
    async handleTool(name, raw) {
      if (name !== 'hotel_create_order') return unsupportedTool();
      try { const args = parseToolArguments(raw); const item = normalizeService(args.item); const quantity = Math.max(1, Math.min(99, Number(args.quantity || 1))); if (!caller.room || !/^\d{1,8}$/.test(caller.room)) return { ok: false, content: '未能读取本次来电的房间分机，暂时无法创建任务。' }; const task = await createTask({ scenario: 'creation', type: 'hotel_service', title: `${item} × ${quantity}（${caller.room}）`, payload: { room_no: caller.room, caller_name: caller.name, caller_number: caller.number, item, quantity, source: 'voice', call_id: call.id, created_from_transcript: call.transcript?.at(-1)?.text || '' }, user_id: userId, workspace_id: 'default' }); return { ok: true, content: `任务已创建：${caller.name ? caller.name + '，' : ''}${caller.room} 房，${quantity} 份${item}。请用当前来电者的语言礼貌回复已安排。任务编号 ${task.id}` }; } catch (error) { return { ok: false, content: error.message || String(error) }; }
    },
  };
}
