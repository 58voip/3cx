import { createRealtimeScenario } from './realtime.mjs';
import { createCreationScenario } from './creation.mjs';
import { createAnalysisScenario } from './analysis.mjs';

const factories = Object.freeze({ realtime: createRealtimeScenario, creation: createCreationScenario, analysis: createAnalysisScenario });
export const scenarioIds = Object.freeze(Object.keys(factories));
export function createScenario(id, context) { const factory = factories[id]; if (!factory) throw new Error(`未知助手场景：${id}`); return factory(context); }
