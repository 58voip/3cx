export function parseToolArguments(value) {
  if (typeof value !== 'string') return value || {};
  try { return JSON.parse(value || '{}'); } catch { throw new Error('工具参数格式不正确'); }
}

export function knowledgeInstructions(settings) {
  const knowledge = String(settings.knowledge || '').trim();
  return [
    '回答规则：优先依据下方知识库回答；知识库没有的信息要明确说不知道，不要编造。一次只问一个必要问题；用户已经回答过的问题不要重复询问。',
    '声音规则：自动识别来电语言；粤语使用粤语声音，普通话使用普通话声音，英语使用英语声音。不要因为文字使用中文就默认使用普通话声音。',
    knowledge ? `【当前场景知识库】\n${knowledge}` : '【当前场景知识库】暂未配置',
  ];
}

export function welcomeRule(languageText) {
  return `欢迎语规则：${languageText}接通后只播放一次欢迎语，来电者没有说新内容时不要重复播放。`;
}

export function unsupportedTool() { return { ok: false, content: '当前 MCP 未启用' }; }
