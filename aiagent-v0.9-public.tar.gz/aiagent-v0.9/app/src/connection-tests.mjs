import { createHash } from 'node:crypto';
import { getSettings, getSecretSetting } from './store.mjs';
import { qwenRealtime } from './config.mjs';
import { customQwenOptions, customDeepseekOptions } from './model-options.mjs';
import { listAuthorizedMcpTools } from './mcp-auth.mjs';
import { queryWeather } from './weather.mjs';
import { testStockMcpConnection } from './stock.mjs';
import { resultStore, visibleResult } from './connection-results.mjs';

const results = new Map();
const persistedResults = resultStore();
const busy = new Set();
const sdk = process.env.AIAGENT_MCP_SDK || '@modelcontextprotocol/sdk';
const kinds = ['mcp', 'threecx', 'notification', 'qwen', 'deepseek'];
function checkedUrl(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.hash) throw Error('服务器地址格式不正确');
  return url;
}
async function configuration(scenario, kind, userId, workspaceId, draft = {}) {
  const s = { ...await getSettings(scenario, userId, workspaceId), ...draft };
  const secret = async (key, scene = scenario) => scene === scenario && String(draft[key] || '').trim() ? String(draft[key]).trim() : getSecretSetting(scene, key, userId, workspaceId);
  const demoSecret = async (key, scene) => await secret(key, scene) || getSecretSetting(scene, key, process.env.AIAGENT_DEMO_USER || userId, workspaceId);
  if (kind === 'qwen') return s.qwen_config_mode === 'custom' ? { ...customQwenOptions(s), apiKey: await secret('custom_qwen_api_key'), voice: s.welcome_voice || s.voices_mandarin || 'Tina' } : { ...qwenRealtime };
  if (kind === 'deepseek') return { ...(s.deepseek_config_mode === 'custom' ? customDeepseekOptions(s) : { baseUrl: s.deepseek_base_url || 'https://your-deepseek-endpoint.example', model: s.deepseek_model || 'deepseek-v4-flash' }), apiKey: s.deepseek_config_mode === 'custom' ? await secret('custom_deepseek_api_key') : await demoSecret('deepseek_api_key', 'analysis') };
  if (kind === 'threecx' || kind === 'notification') return { baseUrl: s.threecx_server || '', clientId: kind === 'notification' ? s.notification_client_id : (scenario === 'analysis' ? s.intake_client_id : s.client_id), apiKey: await secret(kind === 'notification' ? 'notification_api_key' : scenario === 'analysis' ? 'analysis_api_key' : 'threecx_api_key') };
  const provider = s.mcp_provider || (s.builtin_weather === 'true' ? 'weather' : 'custom');
  if (provider === 'weather') return { provider, apiKey: await demoSecret('amap_weather_api_key', 'realtime') };
  if (provider === 'stock') { const stock = await getSettings('realtime', userId, workspaceId); return { provider, baseUrl: stock.stock_mcp_url || 'https://mcp.twelvedata.com/mcp', apiKey: await demoSecret('stock_mcp_token', 'realtime'), auth: 'token' }; }
  return { provider: 'custom', baseUrl: s.mcp_url || '', auth: s.auth_mode || 'oauth', apiKey: await secret('mcp_token') };
}
function hasConfig(c) { return Boolean(c.apiKey || c.clientId || (!c.model && c.provider !== 'weather' && c.provider !== 'stock' && c.baseUrl)); }
function digest(c) { return createHash('sha256').update(JSON.stringify(c)).digest('hex'); }
async function jsonRequest(url, options = {}) {
  checkedUrl(url);
  const r = await fetch(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw Error(`接口返回 HTTP ${r.status}${r.status === 401 || r.status === 403 ? '，请检查密钥及权限' : ''}`);
  return r.json();
}
async function mcpTools(c) {
  const [{ Client }, { StreamableHTTPClientTransport }] = await Promise.all([import(`${sdk}/client/index.js`), import(`${sdk}/client/streamableHttp.js`)]);
  const client = new Client({ name: 'aiagent-connection-test', version: '1.0.0' }, { capabilities: {} });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 18000);
  const transport = new StreamableHTTPClientTransport(checkedUrl(c.baseUrl), { requestInit: { headers: c.apiKey ? { Authorization: `Bearer ${c.apiKey}` } : {} }, fetch: (url, options) => fetch(url, { ...options, redirect: 'error', signal: controller.signal }) });
  try { await client.connect(transport); const tools = []; let cursor; do { const page = await client.listTools(cursor ? { cursor } : {}); tools.push(...page.tools); cursor = page.nextCursor; } while (cursor && tools.length < 1000); return tools; }
  finally { clearTimeout(timer); controller.abort(); await client.close().catch(() => {}); }
}
async function qwenTest(c) {
  const { default: WebSocket } = await import(process.env.AIAGENT_WS_MODULE || 'ws');
  const url = checkedUrl(c.baseUrl); url.protocol = 'wss:'; url.pathname = '/api-ws/v1/realtime'; url.search = new URLSearchParams({ model: c.model }).toString();
  await new Promise((resolve, reject) => {
    let settled = false;
    const socket = new WebSocket(url, { headers: { Authorization: `Bearer ${c.apiKey}` }, handshakeTimeout: 12000 });
    const done = (error) => { if (settled) return; settled = true; clearTimeout(timer); socket.terminate(); error ? reject(error) : resolve(); };
    const timer = setTimeout(() => done(Error('Qwen 会话验证超时')), 18000);
    socket.on('open', () => socket.send(JSON.stringify({ type: 'session.update', session: { modalities: ['text', 'audio'], voice: c.voice || 'Tina', input_audio_format: 'pcm', output_audio_format: 'pcm', turn_detection: { type: 'server_vad', silence_duration_ms: c.vadSilenceDurationMs || 2400 } } })));
    socket.on('message', raw => { try { const event = JSON.parse(String(raw)); if (event.type === 'session.updated') done(); if (event.type === 'error') done(Error('Qwen 拒绝会话配置，请检查模型、音色、地域与密钥')); } catch {} });
    socket.on('unexpected-response', (_req, res) => { res.resume(); done(Error(`Qwen 鉴权失败（HTTP ${res.statusCode}），请检查地域、工作空间和密钥`)); });
    socket.on('error', () => done(Error('Qwen 连接失败，请检查服务器地址与网络')));
    socket.on('close', () => done(Error('Qwen 未确认会话配置就关闭了连接')));
  });
}
export async function connectionState(scenario, kind, userId, workspaceId, draft = {}, run = false) {
  if (!['realtime', 'creation', 'analysis'].includes(scenario) || !kinds.includes(kind)) throw Error('测试类型不正确');
  const key = JSON.stringify([workspaceId, userId, scenario, kind]);
  let c;
  try { c = await configuration(scenario, kind, userId, workspaceId, draft); } catch (e) { return { state: 'untested', message: '配置待完善：' + e.message }; }
  const fingerprint = digest(c);
  if (!run) {
    let prior = results.get(key);
    try { const disk = await persistedResults.read(key); if (disk && (!prior || disk.at > prior.at)) prior = disk; } catch { /* Keep the current process result if storage is temporarily unavailable. */ }
    return visibleResult(prior, fingerprint, hasConfig(c));
  }
  if (busy.has(key)) return { state: 'untested', message: '测试正在进行，请稍候' };
  busy.add(key);
  let result;
  try {
    if (!hasConfig(c)) { result = { state: 'empty', message: '未填写' }; return result; }
    let message, discoveredTools;
    if (kind === 'mcp') {
      if (c.provider === 'weather') { if (!c.apiKey) throw Error('天气演示密钥未配置'); await queryWeather('110000'); message = '天气接口查询成功'; }
      else if (c.provider === 'stock') {
        const tools = await testStockMcpConnection(userId, workspaceId);
        discoveredTools = tools.map(tool => ({ name: tool.name, description: tool.description || '' }));
        message = `连接成功，已读取 ${tools.length} 个工具`;
      } else {
        if (!c.baseUrl) throw Error('请填写 MCP 地址');
        let tools;
        if (c.auth === 'oauth' && c.provider === 'custom') throw Error('公开版本请使用访问令牌连接 MCP');
        if (c.auth === 'token' && !c.apiKey) throw Error('请填写访问令牌');
        tools = await mcpTools(c);
        discoveredTools = tools.map(tool => ({ name: tool.name, description: tool.description || '' }));
        message = `连接成功，已读取 ${tools.length} 个工具`;
      }
    } else {
      if (!c.apiKey) throw Error('请填写 API Key');
      if (!c.baseUrl) throw Error('请填写服务器地址');
      if (kind === 'qwen') { await qwenTest(c); message = 'Qwen 鉴权及会话配置成功'; }
      else if (kind === 'deepseek') {
        const data = await jsonRequest(c.baseUrl.replace(/\/$/, '') + '/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.apiKey}` }, body: JSON.stringify({ model: c.model, messages: [{ role: 'user', content: 'Reply OK.' }], max_tokens: 64, stream: false }) });
        if (!data.choices?.length || !(data.choices[0].message?.content || data.choices[0].message?.reasoning_content)) throw Error('模型未返回有效内容');
        message = '模型请求成功';
      } else {
        if (!c.clientId) throw Error('请填写 3CX API ID');
        const base = c.baseUrl.replace(/\/$/, '');
        const token = await jsonRequest(base + '/connect/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'client_credentials', client_id: c.clientId, client_secret: c.apiKey }) });
        if (!token.access_token) throw Error('3CX 未返回访问令牌');
        const data = await jsonRequest(base + '/callcontrol', { headers: { Authorization: `Bearer ${token.access_token}` } });
        if (!Array.isArray(data)) throw Error('Call Control 返回格式不正确');
        message = '3CX 鉴权和 Call Control 权限验证成功';
      }
    }
    result = { state: 'success', message, ...(discoveredTools ? { tools: discoveredTools } : {}), testedAt: new Date().toISOString() };
  } catch (error) {
    // Do not expose upstream response bodies, URLs or credentials in browser errors.
    let message = String(error.message || '连接失败');
    if (c.apiKey) message = message.split(c.apiKey).join('[已隐藏]');
    if (/https?:|wss?:|fetch failed|ENOENT/i.test(message)) message = '连接失败，请检查地址、授权和网络';
    result = { state: 'failed', message: message.slice(0, 200), testedAt: new Date().toISOString() };
  } finally { busy.delete(key); }
  if (results.size > 1000) results.delete(results.keys().next().value);
  let resultFingerprint = fingerprint;
  if (result.state === 'success') {
    try { resultFingerprint = digest(await configuration(scenario, kind, userId, workspaceId, draft)); }
    catch { /* The successful result remains valid for the tested in-memory configuration. */ }
  }
  const entry = { fingerprint: resultFingerprint, at: Date.now(), result };
  results.set(key, entry);
  try { await persistedResults.save(key, entry); }
  catch { result.message += '（结果未能保存，重启后需复测）'; }
  return visibleResult(entry, resultFingerprint, hasConfig(c));
}
