import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { customQwenOptions, customDeepseekOptions } from './model-options.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = resolve(root, 'data');
const tasksFile = resolve(dataDir, 'tasks.json');
const callsFile = resolve(dataDir, 'calls.json');
const settingsFile = resolve(dataDir, 'settings.json');
const secretsFile = resolve(dataDir, 'secrets.json');
const secretKeyFile = resolve(dataDir, '.settings-key');
const pendingReportsFile = resolve(dataDir, 'analysis-pending-reports.json');
const modelSecretNames = ['custom_qwen_api_key', 'custom_deepseek_api_key', 'mcp_token'];
const systemSettingsKey = 'system:email';

const scenarios = [
  { id: 'realtime', name: '实时语音助手', mode: 'conversation' },
  { id: 'creation', name: '语音创建助手', mode: 'task_creation' },
  { id: 'analysis', name: '语音分析助手', mode: 'analysis_intake' },
];

const sharedDefaults = { qwen_config_mode: 'demo', deepseek_config_mode: 'demo', mcp_provider: 'weather', builtin_weather: 'true', language_mode: 'auto', welcome_language: 'auto', welcome_voice: 'Tina', voices_mandarin: 'Tina', voices_cantonese: 'Kiki', voices_english: 'Maia' };
const scenarioDefaults = {
  realtime: { ...sharedDefaults, welcome: '您好，这里是 AI 语音助手，请问有什么可以帮您？' },
  creation: { ...sharedDefaults, welcome: '您好，请告诉我需要安排的服务。', task_reply: '好的，我马上安排。' },
  analysis: { ...sharedDefaults, welcome: '您好，请告诉我需要分析的内容。', task_reply: '好的，已创建分析任务，完成后会回拨通知。', callback_language: 'auto', callback_voice: 'Tina', callback_max_chars: 180 },
};

async function readTasks() {
  try { return JSON.parse(await readFile(tasksFile, 'utf8')); }
  catch { return []; }
}

async function saveTasks(tasks) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(tasksFile, JSON.stringify(tasks, null, 2) + '\n', 'utf8');
}

async function readCalls() {
  try { return JSON.parse(await readFile(callsFile, 'utf8')); }
  catch { return []; }
}

async function saveCalls(calls) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(callsFile, JSON.stringify(calls, null, 2) + '\n', 'utf8');
  chmodSync(callsFile, 0o600);
}

async function readSettings() {
  try { return JSON.parse(await readFile(settingsFile, 'utf8')); }
  catch { return {}; }
}

async function saveSettings(settings) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(settingsFile, JSON.stringify(settings, null, 2) + '\n', 'utf8');
  chmodSync(settingsFile, 0o600);
}

function key() { if (!existsSync(secretKeyFile)) { mkdirSync(dataDir, { recursive: true }); writeFileSync(secretKeyFile, randomBytes(32), { mode: 0o600 }); } return readFileSync(secretKeyFile); }
function seal(value) { const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', key(), iv); const body = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]); return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64url'); }
function secretValues() { try { const raw = JSON.parse(openSecret(readFileSync(secretsFile, 'utf8'))); return raw; } catch { return {}; } }
function openSecret(value) { const raw = Buffer.from(value, 'base64url'); const decipher = createDecipheriv('aes-256-gcm', key(), raw.subarray(0, 12)); decipher.setAuthTag(raw.subarray(12, 28)); return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8'); }
function saveSecretValues(values) { writeFileSync(secretsFile, seal(JSON.stringify(values)), { mode: 0o600 }); chmodSync(secretsFile, 0o600); }

export function listScenarios() { return scenarios; }

export async function listTasks(scenario = '', userId = 'default', workspaceId = 'default') {
  const tasks = await readTasks();
  return tasks.filter((task) => (!scenario || task.scenario === scenario) && task.user_id === userId && task.workspace_id === workspaceId);
}

export async function listAllTasks(scenario = '') {
  const tasks = await readTasks();
  return tasks.filter((task) => !scenario || task.scenario === scenario);
}

export async function listCalls(userId = 'default', workspaceId = 'default') {
  const calls = await readCalls();
  return calls.filter((call) => call.user_id === userId && call.workspace_id === workspaceId);
}

export async function createCall(input = {}) {
  const now = new Date().toISOString();
  const call = {
    id: `call-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    scenario: String(input.scenario || 'realtime'),
    caller: String(input.caller || '未知来电'),
    caller_name: String(input.caller_name || '').trim(),
    room_no: String(input.room_no || '').trim(),
    caller_number: String(input.caller_number || '').trim(),
    callee_name: String(input.callee_name || '').trim(),
    callee_number: String(input.callee_number || '').trim(),
    direction: String(input.direction || 'inbound'),
    status: 'in_progress',
    started_at: now,
    ended_at: null,
    duration_seconds: 0,
    user_id: String(input.user_id || 'default'),
    workspace_id: String(input.workspace_id || 'default'),
  };
  const calls = await readCalls();
  calls.unshift(call);
  await saveCalls(calls);
  return call;
}

export async function finishCall(id, input = {}) {
  const calls = await readCalls();
  const call = calls.find((item) => item.id === id);
  if (!call) return null;
  const endedAt = new Date().toISOString();
  call.ended_at = endedAt;
  call.status = String(input.status || 'completed');
  call.duration_seconds = Math.max(0, Math.round((Date.parse(endedAt) - Date.parse(call.started_at)) / 1000));
  await saveCalls(calls);
  return call;
}

export async function updateCall(id, patch = {}) {
  const calls = await readCalls();
  const call = calls.find((item) => item.id === id);
  if (!call) return null;
  Object.assign(call, patch, { updated_at: new Date().toISOString() });
  await saveCalls(calls);
  return call;
}

export async function getSettings(scenario = '', userId = 'default', workspaceId = 'default') {
  const settings = await readSettings();
  const result = { ...(scenarioDefaults[scenario] || {}), ...(settings[`${workspaceId}:${userId}:${scenario}`] || {}) };
  for (const name of [...modelSecretNames, 'threecx_api_key', 'analysis_api_key', 'notification_api_key', 'callback_api_key', 'deepseek_api_key', 'amap_weather_api_key', 'stock_mcp_token', 'stock_mcp_oauth_tokens', 'stock_mcp_oauth_client']) { delete result[name]; result[`${name}_configured`] = Boolean(secretValues()[`${workspaceId}:${userId}:${scenario}:${name}`]); }
  return result;
}

export async function recordingOwnedBy(name, userId, workspaceId) {
  const path = `/media/recordings/${name}`;
  return (await readCalls()).some((call) => call.user_id === userId && call.workspace_id === workspaceId && [call.caller_audio, call.assistant_audio].includes(path));
}

export async function getSecretSetting(scenario, name, userId = 'default', workspaceId = 'default') {
  return secretValues()[`${workspaceId}:${userId}:${scenario}:${name}`] || '';
}

export async function getSystemEmailSettings(includePassword = false) {
  const settings = await readSettings();
  const value = { ...(settings[systemSettingsKey] || {}) };
  const password = secretValues()[`${systemSettingsKey}:smtp_password`] || '';
  value.smtp_password_configured = Boolean(password);
  if (includePassword) value.smtp_password = password;
  return value;
}

export async function updateSystemEmailSettings(values = {}) {
  const settings = await readSettings(); const current = settings[systemSettingsKey] || {};
  const allowed = ['smtp_host', 'smtp_port', 'smtp_secure', 'smtp_username', 'smtp_from_name', 'smtp_from_email', 'welcome_subject', 'welcome_body'];
  const next = { ...current };
  for (const key of allowed) if (values[key] !== undefined) next[key] = String(values[key]).trim();
  if (values.smtp_password && !String(values.smtp_password).startsWith('••')) { const secrets = secretValues(); secrets[`${systemSettingsKey}:smtp_password`] = String(values.smtp_password); saveSecretValues(secrets); }
  next.updated_at = new Date().toISOString(); settings[systemSettingsKey] = next; await saveSettings(settings); return getSystemEmailSettings(false);
}

export async function updateSettings(scenario, values, userId = 'default', workspaceId = 'default') {
  if (!scenarios.some((item) => item.id === scenario)) throw new Error('不支持的场景');
  const settings = await readSettings();
  const key = `${workspaceId}:${userId}:${scenario}`;
  const nextValues = { ...values };
  const secrets = secretValues();
  for (const name of [...modelSecretNames, 'threecx_api_key', 'analysis_api_key', 'notification_api_key', 'callback_api_key', 'deepseek_api_key', 'amap_weather_api_key', 'stock_mcp_token', 'stock_mcp_oauth_tokens', 'stock_mcp_oauth_client']) { if (nextValues[name] && !String(nextValues[name]).startsWith('••')) secrets[`${key}:${name}`] = String(nextValues[name]); delete nextValues[name]; }
  for (const provider of ['qwen', 'deepseek']) {
    const mode = nextValues[provider + '_config_mode'];
    if (mode !== undefined && !['demo', 'custom'].includes(mode)) throw new Error('模型配置方式不合法');
    if (mode === 'custom' && !secrets[key + ':custom_' + provider + '_api_key']) throw new Error('请填写 ' + provider + ' API Key');
  }
  for (const name of Object.keys(nextValues)) if (name.endsWith('_configured')) delete nextValues[name];
  const merged = { ...(settings[key] || {}), ...nextValues };
  if (merged.qwen_config_mode === 'custom') customQwenOptions(merged);
  if (merged.deepseek_config_mode === 'custom') customDeepseekOptions(merged);
  saveSecretValues(secrets);
  settings[key] = { ...(settings[key] || {}), ...nextValues, scenario, user_id: userId, workspace_id: workspaceId, updated_at: new Date().toISOString() };
  await saveSettings(settings);
  return settings[key];
}

export async function scenarioRuntimeStatus(userId = 'default', workspaceId = 'default') {
  const settings = await readSettings();
  return scenarios.map(({ id, name, mode }) => {
    const item = settings[`${workspaceId}:${userId}:${id}`] || {};
    const clientId = item.client_id || item.intake_client_id || '';
    return { id, name, mode, configured: Boolean(clientId), clientId: clientId ? String(clientId) : '' };
  });
}

export async function assertThreeCxIdsAvailable(values, userId, workspaceId = 'default') {
  const ids = values.map((value) => String(value || '').trim()).filter(Boolean);
  if (new Set(ids).size !== ids.length) throw new Error('同一账户不能重复使用相同的 3CX API ID');
  const wanted = new Set(ids);
  const settings = await readSettings();
  for (const item of Object.values(settings)) {
    if (!item || (item.user_id === userId && item.workspace_id === workspaceId)) continue;
    for (const id of [item.client_id, item.intake_client_id, item.notification_client_id].map((value) => String(value || '').trim())) {
      if (id && wanted.has(id)) throw new Error(`3CX API ID ${id} 已被其他用户使用`);
    }
  }
}

export async function createTask(input) {
  if (!scenarios.some((scenario) => scenario.id === input.scenario)) throw new Error('不支持的场景');
  const tasks = await readTasks();
  // A realtime model may emit the same analysis tool call twice while the
  // caller is still speaking. One inbound call must produce one analysis
  // task, and therefore one automatic callback.
  const sourceCallId = String(input.payload?.call_id || '').trim();
  if (input.scenario === 'analysis' && sourceCallId) {
    const existing = tasks.find((task) => task.scenario === 'analysis' && task.user_id === String(input.user_id || 'default') && task.workspace_id === String(input.workspace_id || 'default') && String(task.payload?.call_id || '') === sourceCallId);
    if (existing) return existing;
  }
  const now = new Date().toISOString();
  const task = {
    id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    scenario: input.scenario,
    type: String(input.type || 'voice_task'),
    status: 'created',
    title: String(input.title || '').trim() || '未命名任务',
    payload: input.payload && typeof input.payload === 'object' ? input.payload : {},
    user_id: String(input.user_id || 'default'),
    workspace_id: String(input.workspace_id || 'default'),
    callback_status: 'not_required',
    created_at: now,
    updated_at: now,
  };
  tasks.unshift(task);
  await saveTasks(tasks);
  return task;
}

export async function updateTask(id, patch = {}) {
  const tasks = await readTasks();
  const task = tasks.find((item) => item.id === id);
  if (!task) return null;
  Object.assign(task, patch, { updated_at: new Date().toISOString() });
  await saveTasks(tasks);
  return task;
}

async function readPendingReports() {
  try { return JSON.parse(await readFile(pendingReportsFile, 'utf8')); }
  catch { return []; }
}

export async function queueAnalysisReport(taskId, extension, report, userId, workspaceId) {
  const target = String(extension || '').trim();
  if (!/^\d+$/.test(target) || !String(report || '').trim()) throw new Error('待播报报告缺少有效分机或内容');
  const pending = (await readPendingReports()).filter((item) => item.consumed_at || item.extension !== target);
  pending.unshift({ id: `report-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, task_id: taskId, extension: target, report: String(report).slice(0, 5000), user_id: userId, workspace_id: workspaceId, created_at: new Date().toISOString(), consumed_at: null });
  await writeFile(pendingReportsFile, JSON.stringify(pending.slice(0, 100), null, 2) + '\n', 'utf8');
}

export async function takeAnalysisReport(userId = '', workspaceId = '') {
  const pending = await readPendingReports();
  const item = pending.find((entry) => !entry.consumed_at && (!userId || entry.user_id === userId) && (!workspaceId || entry.workspace_id === workspaceId));
  if (!item) return null;
  item.consumed_at = new Date().toISOString();
  await writeFile(pendingReportsFile, JSON.stringify(pending, null, 2) + '\n', 'utf8');
  return item;
}

// The first version stored data in the default workspace. Keep that data available
// to the runtime while copying it into the authenticated owner's namespace.
export async function migrateDefaultUserData(userId) {
  if (!userId || userId === 'default') return;
  const settings = await readSettings();
  for (const scenario of scenarios) {
    const source = `default:default:${scenario.id}`;
    const target = `default:${userId}:${scenario.id}`;
    if (settings[source] && !settings[target]) settings[target] = { ...settings[source], user_id: userId };
  }
  await saveSettings(settings);
  for (const file of [tasksFile, callsFile]) {
    try {
      const items = JSON.parse(await readFile(file, 'utf8'));
      let changed = false;
      for (const item of items) if (item.user_id === 'default' && item.workspace_id === 'default') { item.user_id = userId; changed = true; }
      if (changed) await writeFile(file, JSON.stringify(items, null, 2) + '\n', 'utf8');
    } catch { /* no records yet */ }
  }
  const secrets = secretValues();
  for (const name of ['threecx_api_key', 'analysis_api_key', 'callback_api_key', 'amap_weather_api_key']) {
    const source = `default:default:realtime:${name}`;
    const target = `default:${userId}:realtime:${name}`;
    if (secrets[source] && !secrets[target]) secrets[target] = secrets[source];
  }
  saveSecretValues(secrets);
}

export async function migrateUserIdentity(previousUserId, nextUserId, workspaceId = 'default') {
  if (!previousUserId || !nextUserId || previousUserId === nextUserId) return;
  const settings = await readSettings();
  for (const scenario of scenarios) {
    const previous = `${workspaceId}:${previousUserId}:${scenario.id}`; const next = `${workspaceId}:${nextUserId}:${scenario.id}`;
    if (settings[previous]) { if (settings[next]) throw new Error('新邮箱已经存在配置数据'); settings[next] = { ...settings[previous], user_id: nextUserId }; delete settings[previous]; }
  }
  await saveSettings(settings);
  const secrets = secretValues(); const prefix = `${workspaceId}:${previousUserId}:`; const nextPrefix = `${workspaceId}:${nextUserId}:`;
  for (const key of Object.keys(secrets)) if (key.startsWith(prefix)) { secrets[nextPrefix + key.slice(prefix.length)] = secrets[key]; delete secrets[key]; }
  saveSecretValues(secrets);
  for (const file of [tasksFile, callsFile, pendingReportsFile]) {
    try { const items = JSON.parse(await readFile(file, 'utf8')); let changed = false; for (const item of items) if (item.user_id === previousUserId && item.workspace_id === workspaceId) { item.user_id = nextUserId; changed = true; } if (changed) await writeFile(file, JSON.stringify(items, null, 2) + '\n', 'utf8'); }
    catch { /* file may not exist yet */ }
  }
}
