import { getSecretSetting } from './store.mjs';

async function amapJson(path, params) {
  const key = await getSecretSetting('realtime', 'amap_weather_api_key', userId, workspaceId);
  if (!key) throw new Error('高德天气 API Key 尚未配置');
  const url = new URL(`https://restapi.amap.com${path}`);
  url.search = new URLSearchParams({ ...params, key, output: 'JSON' }).toString();
  const response = await fetch(url, { signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw new Error(`高德天气接口 HTTP ${response.status}`);
  const payload = await response.json();
  if (payload.status !== '1') throw new Error(`高德天气接口：${payload.info || '查询失败'}`);
  return payload;
}

export async function queryWeather(city, forecast = false) {
  const input = String(city || '').trim();
  if (!input) throw new Error('请提供城市名称');
  const geocoded = /^\d{6}$/.test(input) ? { adcode: input, name: input } : ((await amapJson('/v3/geocode/geo', { address: input })).geocodes?.[0] ?? {});
  const adcode = String(geocoded.adcode || '');
  if (!adcode) throw new Error(`没有找到城市“${input}”的行政区编码`);
  const payload = await amapJson('/v3/weather/weatherInfo', { city: adcode, extensions: forecast ? 'all' : 'base' });
  const item = forecast ? payload.forecasts?.[0] : payload.lives?.[0];
  if (!item) throw new Error('高德没有返回天气数据');
  return JSON.stringify({ source: '高德天气', city: item.city || geocoded.city || input, reporttime: item.reporttime, forecast, weather: forecast ? item.casts : item }, null, 2);
}
