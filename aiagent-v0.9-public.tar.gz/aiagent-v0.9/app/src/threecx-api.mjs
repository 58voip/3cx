import { getSecretSetting, getSettings } from './store.mjs';

export async function listThreeCxDestinations(userId = process.env.AIAGENT_ADMIN_USER || 'configured-user', workspaceId = 'default', scenario = 'realtime') {
  const settings = await getSettings(scenario, userId, workspaceId);
  const appId = String(settings.client_id || settings.intake_client_id || '').trim();
  const secret = await getSecretSetting(scenario, scenario === 'analysis' ? 'analysis_api_key' : 'threecx_api_key', userId, workspaceId);
  const base = String(settings.threecx_server || '').replace(/\/$/, '');
  if (!base || !appId || !secret) return { ok: false, destinations: [], message: '请先完成当前场景的 3CX API ID 设置' };
  try {
    const tokenResponse = await fetch(`${base}/connect/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'client_credentials', client_id: appId, client_secret: secret }), signal: AbortSignal.timeout(10000) });
    if (!tokenResponse.ok) return { ok: false, destinations: [], message: `3CX 鉴权失败（HTTP ${tokenResponse.status}）` };
    const token = (await tokenResponse.json()).access_token || '';
    const headers = { Authorization: `Bearer ${token}`, Accept: 'application/json' };
    const [usersResponse, queuesResponse, callControlResponse] = await Promise.all([
      fetch(`${base}/xapi/v1/Users?$top=200&$select=Id,FirstName,LastName,Number,EmailAddress`, { headers, signal: AbortSignal.timeout(10000) }),
      fetch(`${base}/xapi/v1/Queues?$top=200&$select=Id,Number,Name`, { headers, signal: AbortSignal.timeout(10000) }),
      fetch(`${base}/callcontrol`, { headers, signal: AbortSignal.timeout(10000) }),
    ]);
    const users = usersResponse.ok ? ((await usersResponse.json()).value || []) : [];
    const userNames = new Map(users.map((u) => [String(u.Number || ''), `${u.FirstName || ''} ${u.LastName || ''}`.trim()]));
    const queues = queuesResponse.ok ? ((await queuesResponse.json()).value || []) : [];
    const queueNames = new Map(queues.map((q) => [String(q.Number || ''), String(q.Name || '')]));
    if (!callControlResponse.ok) return { ok: false, destinations: [], message: `Call Control 分机清单读取失败（HTTP ${callControlResponse.status}）` };
    const allowed = await callControlResponse.json();
    const destinations = [];
    for (const item of Array.isArray(allowed) ? allowed : []) {
      const number = String(item.dn || '').trim();
      if (!number || number === appId) continue;
      const queue = String(item.type || '').toLowerCase().includes('queue');
      destinations.push({ type: queue ? 'queue' : 'extension', number, name: queue ? (queueNames.get(number) || `队列 ${number}`) : (userNames.get(number) || `分机 ${number}`) });
    }
    const allowedNumbers = new Set(destinations.map((item) => item.number));
    const people = destinations.filter((item) => item.type === 'extension').map((item) => ({ number: item.number, name: userNames.get(item.number) || item.name || `分机 ${item.number}` })).filter((user) => user.number && user.number !== appId);
    return { ok: true, destinations, people, message: `已读取 ${destinations.length} 个可用转接目标和 ${people.length} 位人员` };
  } catch (error) { return { ok: false, destinations: [], message: `读取 3CX 分机失败：${error instanceof Error ? error.message : String(error)}` }; }
}
