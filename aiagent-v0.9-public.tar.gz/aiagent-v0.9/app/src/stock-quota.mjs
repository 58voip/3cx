import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const file = resolve(process.env.AIAGENT_DATA_DIR || resolve(process.cwd(), 'data'), 'stock-usage.json');
const DAILY_LIMIT = 800;
const MINUTE_LIMIT = 8;
const MIN_INTERVAL_MS = 7500;
let tail = Promise.resolve();

function today() { return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Shanghai' }); }
async function readUsage() { try { const value = JSON.parse(await readFile(file, 'utf8')); return value.date === today() ? value : { date: today(), dailyUsed: 0, requestTimestamps: [] }; } catch { return { date: today(), dailyUsed: 0, requestTimestamps: [] }; } }
async function writeUsage(value) { await mkdir(resolve(file, '..'), { recursive: true }); await writeFile(file, JSON.stringify(value, null, 2) + '\n', 'utf8'); }

export async function reserveStockSlot(onWait) {
  let release;
  const previous = tail;
  tail = new Promise((resolveRelease) => { release = resolveRelease; });
  await previous;
  try {
    for (;;) {
      const now = Date.now(); const usage = await readUsage();
      if (usage.dailyUsed >= DAILY_LIMIT) { const error = new Error('股票免费额度已用光'); error.code = 'STOCK_DAILY_QUOTA'; throw error; }
      usage.requestTimestamps = (usage.requestTimestamps || []).filter((value) => value > now - 60_000);
      const oldest = usage.requestTimestamps[0]; const last = usage.requestTimestamps.at(-1);
      const waitMs = usage.requestTimestamps.length >= MINUTE_LIMIT ? Math.max(100, oldest + 60_000 - now) : last ? Math.max(0, last + MIN_INTERVAL_MS - now) : 0;
      if (waitMs > 0) { onWait?.(waitMs, usage.requestTimestamps.length >= MINUTE_LIMIT); await new Promise((resolveWait) => setTimeout(resolveWait, waitMs)); continue; }
      usage.dailyUsed += 1; usage.requestTimestamps.push(Date.now()); await writeUsage(usage); return;
    }
  } finally { release(); }
}
