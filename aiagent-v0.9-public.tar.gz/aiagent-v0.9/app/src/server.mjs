import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertThreeCxIdsAvailable, createTask, getSettings, getSystemEmailSettings, listCalls, listScenarios, listTasks, migrateDefaultUserData, migrateUserIdentity, recordingOwnedBy, scenarioRuntimeStatus, updateSettings, updateSystemEmailSettings } from './store.mjs';
import { publicConfigStatus } from './config.mjs';
import { page } from './ui.mjs';
import { onboardingPage, passwordPage, registrationPage } from './onboarding-ui.mjs';
import { beginMcpOAuth, finishMcpOAuth, listAuthorizedMcpTools, migrateMcpIdentity } from './mcp-auth.mjs';
import { reloadThreeCxRuntime, runtimeStatus, startThreeCxRuntime, stopThreeCxRuntime } from './threecx-runtime.mjs';
import { retryAnalysisCallback, startAnalysisRunner } from './analysis-runner.mjs';
import { approveUser, changePassword, confirmEmailChange, createUser, getUser, listUsers, login, loginPage, loginWithEmailCode, logout, registerUser, requestEmailChange, requestEmailCode, sessionFrom, updateProfile, updateUser } from './auth.mjs';
import { sendWelcomeEmail, testEmailSettings } from './email.mjs';
import { listThreeCxDestinations } from './threecx-api.mjs';
import { connectionState } from './connection-tests.mjs';
import { connectionOriginAllowed } from './request-origin.mjs';

const host = process.env.AIAGENT_HOST || '0.0.0.0';
const port = Number(process.env.AIAGENT_PORT || YOUR_HTTP_PORT);
const recordingsDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'recordings');
const assetsDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'assets');
const loginAttempts = new Map();
const MAX_BODY_BYTES = 64 * 1024;

function securityHeaders() {
  return { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin', 'Permissions-Policy': 'camera=(), geolocation=(), microphone=()', 'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'" };
}

function clientAddress(req) { return String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim(); }

function loginAllowed(req) {
  const now = Date.now();
  const item = loginAttempts.get(clientAddress(req)) || { count: 0, resetAt: now + 15 * 60 * 1000 };
  if (item.resetAt <= now) { item.count = 0; item.resetAt = now + 15 * 60 * 1000; }
  if (item.count >= 8) return false;
  item.count += 1;
  loginAttempts.set(clientAddress(req), item);
  return true;
}

function identity(req, url) {
  const session = sessionFrom(req);
  return {
    userId: session?.userId || 'default',
    workspaceId: session?.workspaceId || 'default',
  };
}

async function validateMcp(input) {
  const value = String(input.url || '').trim();
  if (!value) throw new Error('请先填写 MCP 服务地址');
  let url;
  try { url = new URL(value); } catch { throw new Error('MCP 服务地址格式不正确'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('MCP 地址必须使用 HTTP 或 HTTPS');
  const started = Date.now();
  try {
    const response = await fetch(url, { method: 'GET', headers: { Accept: 'application/json, text/event-stream' }, signal: AbortSignal.timeout(8000) });
    const authRequired = response.status === 401 || response.status === 403;
    return { ok: response.ok || authRequired, status: response.status, authRequired, mode: String(input.auth_mode || 'oauth'), latencyMs: Date.now() - started, message: authRequired ? '地址可达，但需要授权或访问令牌' : (response.ok ? '地址可达，可继续发现 MCP 工具' : `地址可达，但返回 HTTP ${response.status}`) };
  } catch (error) { return { ok: false, status: 0, authRequired: false, mode: String(input.auth_mode || 'oauth'), latencyMs: Date.now() - started, message: error instanceof Error ? `连接失败：${error.message}` : '连接失败' }; }
}

function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { ...securityHeaders(), 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data) });
  res.end(data);
}

async function body(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > MAX_BODY_BYTES) throw new Error('请求内容过大'); chunks.push(chunk); }
  if (!chunks.length) return {};
  const text = Buffer.concat(chunks).toString('utf8');
  if (String(req.headers['content-type'] || '').includes('application/x-www-form-urlencoded')) return Object.fromEntries(new URLSearchParams(text));
  return JSON.parse(text);
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/login') { if (sessionFrom(req)) { res.writeHead(302, { ...securityHeaders(), Location: '/' }); return res.end(); } res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(loginPage().replace('</main>', '<a href="/register" style="display:block;text-align:center;color:#92a8c2;text-decoration:none;margin-top:16px">注册账户</a></main>')); }
    if (req.method === 'GET' && url.pathname === '/register') { if (sessionFrom(req)) { res.writeHead(302, { ...securityHeaders(), Location: '/' }); return res.end(); } res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(registrationPage()); }
    if (req.method === 'POST' && url.pathname === '/api/auth/login') { if (!loginAllowed(req)) { res.writeHead(429, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8', 'Retry-After': '900' }); return res.end(loginPage('登录尝试过于频繁，请 15 分钟后再试')); } const raw = await body(req); const form = typeof raw === 'object' ? raw : {}; const result = await login(form.username, form.password); if (!result) { res.writeHead(401, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(loginPage('用户名或密码错误')); } if (result.user.role === 'admin') await migrateDefaultUserData(result.user.username); loginAttempts.delete(clientAddress(req)); res.writeHead(302, { ...securityHeaders(), Location: result.user.mustChangePassword ? '/password' : '/', 'Set-Cookie': `aiagent_session=${encodeURIComponent(result.token)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=604800` }); return res.end(); }
    if (req.method === 'POST' && url.pathname === '/api/auth/logout') { logout(req); res.writeHead(302, { ...securityHeaders(), Location: '/login', 'Set-Cookie': 'aiagent_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0' }); return res.end(); }
    if (req.method === 'POST' && url.pathname === '/api/auth/email/send') { if (!loginAllowed(req)) return send(res, 429, { ok: false, error: '发送过于频繁，请稍后再试' }); const input = await body(req); await requestEmailCode(input.username); return send(res, 200, { ok: true, message: '如果该邮箱已启用，验证码将发送到邮箱' }); }
    if (req.method === 'POST' && url.pathname === '/api/auth/email/login') { const input = await body(req); const result = await loginWithEmailCode(input.username, input.code); if (!result) return send(res, 401, { ok: false, error: '验证码错误或已过期' }); loginAttempts.delete(clientAddress(req)); res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': `aiagent_session=${encodeURIComponent(result.token)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=604800` }); return res.end(JSON.stringify({ ok: true, redirect: result.user.mustChangePassword ? '/password' : '/' })); }
    if (req.method === 'POST' && url.pathname === '/api/auth/register') { if (!loginAllowed(req)) return send(res, 429, { ok: false, error: '提交过于频繁，请稍后再试' }); const user = await registerUser(await body(req)); return send(res, 201, { ok: true, message: '注册申请已提交，请等待管理员审批', user: { username: user.username } }); }
    if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, service: 'aiagent', port, callControl: { state: 'not_started', message: '新应用 3CX Call Control 运行时尚未启动' }, qwenRealtime: { configured: publicConfigStatus().configured, model: publicConfigStatus().model } });
    if (req.method === 'GET' && url.pathname === '/assets/3cx-white.png') { const file = resolve(assetsDir, '3cx-white.png'); if (!existsSync(file)) return send(res, 404, { ok: false, error: '资源不存在' }); const image = await readFile(file); res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'image/png', 'Content-Length': image.length, 'Cache-Control': 'public, max-age=86400' }); return res.end(image); }
    if (!sessionFrom(req)) { if (req.method === 'GET' && ['/', '/password', '/setup'].includes(url.pathname)) { res.writeHead(302, { Location: '/login' }); return res.end(); } return send(res, 401, { ok: false, error: '请先登录' }); }
    if (req.method === 'GET' && url.pathname === '/password') { res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(passwordPage()); }
    if (sessionFrom(req).mustChangePassword && !(req.method === 'POST' && ['/api/auth/password', '/api/auth/logout'].includes(url.pathname))) { if (req.method === 'GET') { res.writeHead(302, { ...securityHeaders(), Location: '/password' }); return res.end(); } return send(res, 403, { ok: false, error: '请先设置新密码' }); }
    if (req.method === 'GET' && url.pathname === '/setup') { res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(onboardingPage()); }
    if (req.method === 'GET' && url.pathname === '/') { const session = sessionFrom(req); res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end(page(session)); }
    if (req.method === 'GET' && url.pathname === '/api/auth/me') return send(res, 200, { ok: true, user: sessionFrom(req) });
    if (req.method === 'POST' && url.pathname === '/api/auth/password') { const input = await body(req); const session = sessionFrom(req); await changePassword(session.userId, input.currentPassword, input.newPassword); return send(res, 200, { ok: true }); }
    if (req.method === 'PUT' && url.pathname === '/api/account/profile') { const session = sessionFrom(req); return send(res, 200, { ok: true, user: await updateProfile(session.userId, await body(req)) }); }
    if (req.method === 'GET' && url.pathname === '/api/account/profile') { const session = sessionFrom(req); return send(res, 200, { ok: true, user: await getUser(session.userId) }); }
    if (req.method === 'POST' && url.pathname === '/api/account/email/send') { const session = sessionFrom(req); const input = await body(req); await requestEmailChange(session.userId, input.email); return send(res, 200, { ok: true, message: '验证码已发送到新邮箱' }); }
    if (req.method === 'POST' && url.pathname === '/api/account/email/confirm') { const session = sessionFrom(req); const input = await body(req); const changed = await confirmEmailChange(session.userId, input.email, input.code); await stopThreeCxRuntime(changed.previous); await migrateUserIdentity(changed.previous, changed.user.username, session.workspaceId); await migrateMcpIdentity(changed.previous, changed.user.username, session.workspaceId); void startThreeCxRuntime(changed.user.username); return send(res, 200, { ok: true, user: changed.user }); }
    if (req.method === 'GET' && url.pathname === '/api/admin/users') { const session = sessionFrom(req); if (session.role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可访问' }); return send(res, 200, { ok: true, users: await listUsers() }); }
    if (req.method === 'POST' && url.pathname === '/api/admin/users') { const session = sessionFrom(req); if (session.role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); const user = await createUser(await body(req)); let welcome_sent = true; try { await sendWelcomeEmail(user); } catch { welcome_sent = false; } return send(res, 201, { ok: true, user, welcome_sent }); }
    if (req.method === 'PUT' && url.pathname.startsWith('/api/admin/users/')) { const session = sessionFrom(req); if (session.role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); const username = decodeURIComponent(url.pathname.slice('/api/admin/users/'.length)); const user = await updateUser(username, await body(req)); if (!user.active) await stopThreeCxRuntime(username); return send(res, 200, { ok: true, user }); }
    if (req.method === 'POST' && url.pathname.match(/^\/api\/admin\/users\/[^/]+\/approve$/)) { if (sessionFrom(req).role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); const username = decodeURIComponent(url.pathname.split('/')[4]); const user = await approveUser(username); let welcome_sent = true; try { await sendWelcomeEmail(user); } catch { welcome_sent = false; } return send(res, 200, { ok: true, user, welcome_sent }); }
    if (req.method === 'POST' && url.pathname.match(/^\/api\/admin\/users\/[^/]+\/welcome$/)) { if (sessionFrom(req).role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); const username = decodeURIComponent(url.pathname.split('/')[4]); const user = (await listUsers()).find((item) => item.username === username); if (!user || !user.active) throw new Error('用户尚未审批或已停用'); await sendWelcomeEmail(user); return send(res, 200, { ok: true, message: '欢迎邮件已发送' }); }
    if (req.method === 'GET' && url.pathname === '/api/admin/system/email') { if (sessionFrom(req).role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可访问' }); return send(res, 200, { ok: true, settings: await getSystemEmailSettings(false) }); }
    if (req.method === 'PUT' && url.pathname === '/api/admin/system/email') { if (sessionFrom(req).role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); return send(res, 200, { ok: true, settings: await updateSystemEmailSettings(await body(req)) }); }
    if (req.method === 'POST' && url.pathname === '/api/admin/system/email/test') { const session = sessionFrom(req); if (session.role !== 'admin') return send(res, 403, { ok: false, error: '仅管理员可操作' }); await testEmailSettings(session.userId); return send(res, 200, { ok: true, message: '测试邮件已发送' }); }
    if (req.method === 'GET' && url.pathname === '/api/scenarios') return send(res, 200, { scenarios: listScenarios() });
    if (req.method === 'GET' && url.pathname === '/api/onboarding/threecx') { const who = identity(req, url); const [realtime, creation, analysis] = await Promise.all(['realtime','creation','analysis'].map((scenario) => getSettings(scenario, who.userId, who.workspaceId))); return send(res, 200, { ok: true, settings: { threecx_server: realtime.threecx_server || creation.threecx_server || analysis.threecx_server || '', realtime_client_id: realtime.client_id || '', realtime_key_configured: realtime.threecx_api_key_configured, creation_client_id: creation.client_id || '', creation_key_configured: creation.threecx_api_key_configured, analysis_client_id: analysis.intake_client_id || '', analysis_key_configured: analysis.analysis_api_key_configured, notification_client_id: analysis.notification_client_id || '', notification_key_configured: analysis.notification_api_key_configured } }); }
    if (req.method === 'PUT' && url.pathname === '/api/onboarding/threecx') { const who = identity(req, url); const input = await body(req); await assertThreeCxIdsAvailable([input.realtime_client_id, input.creation_client_id, input.analysis_client_id, input.notification_client_id], who.userId, who.workspaceId); const shared = { threecx_server: String(input.threecx_server || '').trim() }; await updateSettings('realtime', { ...shared, client_id: input.realtime_client_id, threecx_api_key: input.realtime_api_key }, who.userId, who.workspaceId); await updateSettings('creation', { ...shared, client_id: input.creation_client_id, threecx_api_key: input.creation_api_key }, who.userId, who.workspaceId); await updateSettings('analysis', { ...shared, intake_client_id: input.analysis_client_id, analysis_api_key: input.analysis_api_key, notification_client_id: input.notification_client_id, notification_api_key: input.notification_api_key }, who.userId, who.workspaceId); void reloadThreeCxRuntime(who.userId); return send(res, 200, { ok: true }); }
    if (req.method === 'GET' && url.pathname === '/api/runtime') { const who = identity(req, url); return send(res, 200, { service: 'aiagent', port, callControl: runtimeStatus(who.userId), qwenRealtime: publicConfigStatus(), scenarios: await scenarioRuntimeStatus(who.userId, who.workspaceId) }); }
    if (req.method === 'GET' && url.pathname === '/api/tasks') { const who = identity(req, url); return send(res, 200, { tasks: await listTasks(url.searchParams.get('scenario') || '', who.userId, who.workspaceId) }); }
    if (req.method === 'GET' && url.pathname === '/api/calls') { const who = identity(req, url); const scenario = url.searchParams.get('scenario') || ''; const calls = await listCalls(who.userId, who.workspaceId); return send(res, 200, { calls: scenario ? calls.filter((call) => call.scenario === scenario) : calls }); }
    if (req.method === 'GET' && url.pathname === '/api/threecx/destinations') { const who = identity(req, url); return send(res, 200, await listThreeCxDestinations(who.userId, who.workspaceId, url.searchParams.get('scenario') || 'realtime')); }
    if (req.method === 'GET' && url.pathname === '/api/threecx/people') { const who = identity(req, url); const result = await listThreeCxDestinations(who.userId, who.workspaceId, url.searchParams.get('scenario') || 'realtime'); return send(res, result.ok ? 200 : 400, { ...result, people: result.people || [] }); }
    if (req.method === 'GET' && url.pathname.startsWith('/media/recordings/')) { const name = url.pathname.slice('/media/recordings/'.length); if (!/^[a-zA-Z0-9._-]+\.wav$/.test(name)) return send(res, 400, { ok: false, error: '文件名不合法' }); const who = identity(req, url); if (!(await recordingOwnedBy(name, who.userId, who.workspaceId))) return send(res, 404, { ok: false, error: '录音不存在' }); const file = resolve(recordingsDir, name); if (!file.startsWith(`${recordingsDir}/`) || !existsSync(file)) return send(res, 404, { ok: false, error: '录音不存在' }); const audio = await readFile(file); res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'audio/wav', 'Content-Length': audio.length, 'Cache-Control': 'private, max-age=3600' }); return res.end(audio); }
    if (req.method === 'POST' && url.pathname === '/api/tasks') { const input = await body(req); const who = identity(req, url); return send(res, 201, { task: await createTask({ ...input, user_id: who.userId, workspace_id: who.workspaceId }) }); }
    if (req.method === 'POST' && url.pathname === '/api/analysis/callback') {
      const input = await body(req); const who = identity(req, url); const taskId = String(input.taskId || '');
      if (!/^task-[a-zA-Z0-9-]+$/.test(taskId)) throw new Error('任务编号不合法');
      const task = (await listTasks('analysis', who.userId, who.workspaceId)).find((item) => item.id === taskId);
      if (!task) throw new Error('未找到该分析任务');
      return send(res, 200, { ok: true, callback: await retryAnalysisCallback(task) });
    }
    if (req.method === 'GET' && url.pathname === '/api/settings') { const who = identity(req, url); return send(res, 200, { settings: await getSettings(url.searchParams.get('scenario') || '', who.userId, who.workspaceId) }); }
    if (req.method === 'POST' && url.pathname === '/api/connections/test') {
      const origin = req.headers.origin;
      if (!connectionOriginAllowed(origin, req.headers.host)) return send(res, 403, { error: '请求来源不允许' });
      const input = await body(req); const who = identity(req, url);
      return send(res, 200, { result: await connectionState(input.scenario, input.kind, who.userId, who.workspaceId, input.values || {}, input.run === true) });
    }
    if (req.method === 'PUT' && url.pathname === '/api/settings') { const input = await body(req); const who = identity(req, url); const values = input.values || {}; const connectionChanged = ['threecx_server','client_id','intake_client_id','notification_client_id','threecx_api_key','analysis_api_key','notification_api_key'].some((key) => Object.hasOwn(values, key)); if (connectionChanged) await assertThreeCxIdsAvailable([values.client_id, values.intake_client_id, values.notification_client_id], who.userId, who.workspaceId); const settings = await updateSettings(String(input.scenario || ''), values, who.userId, who.workspaceId); if (connectionChanged) void reloadThreeCxRuntime(who.userId); else void startThreeCxRuntime(who.userId); return send(res, 200, { settings }); }
    if (req.method === 'POST' && url.pathname === '/api/mcp/validate') return send(res, 200, { result: await validateMcp(await body(req)) });
    if (req.method === 'GET' && url.pathname === '/api/mcp/tools') { const who = identity(req, url); const tools = await listAuthorizedMcpTools(url.searchParams.get('scenario') || 'analysis', undefined, who.userId, who.workspaceId); return send(res, 200, { ok: true, tools, validatedAt: new Date().toISOString() }); }
    if (req.method === 'POST' && url.pathname === '/api/mcp/oauth/start') { const input = await body(req); const who = identity(req, url); const callback = String(input.callbackUrl || `${url.origin}/api/mcp/oauth/callback`); return send(res, 200, { authorizationUrl: await beginMcpOAuth(String(input.name || 'default'), String(input.url || ''), callback, who.userId, who.workspaceId) }); }
    if (req.method === 'GET' && url.pathname === '/api/mcp/oauth/callback') { const result = await finishMcpOAuth(url.searchParams.get('code') || '', url.searchParams.get('state') || ''); await updateSettings(result.name, { mcp_url: result.serverUrl, auth_mode: 'oauth', oauth_status: 'authorized' }, result.userId, result.workspaceId); res.writeHead(200, { ...securityHeaders(), 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<h2>MCP OAuth 授权完成</h2><p>可以返回 AI 语音助手。</p>'); }
    return send(res, 404, { ok: false, error: 'Not found' });
  } catch (error) {
    return send(res, 400, { ok: false, error: error instanceof Error ? error.message : String(error) });
  }
});

server.listen(port, host, () => { console.log(`AI Agent listening on http://${host}:${port}`); void listUsers().then((items) => Promise.all(items.filter((user) => user.active).map((user) => startThreeCxRuntime(user.username)))); void startAnalysisRunner(); });
