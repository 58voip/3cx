import { connect as tlsConnect } from 'node:tls';
import { connect as netConnect } from 'node:net';
import { getSystemEmailSettings } from './store.mjs';

function readReply(socket, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    let text = ''; const timer = setTimeout(() => done(new Error('SMTP 响应超时')), timeoutMs);
    const onData = (chunk) => { text += chunk.toString('utf8'); const lines = text.split(/\r?\n/).filter(Boolean); const last = lines.at(-1) || ''; if (/^\d{3} /.test(last)) done(null, { code: Number(last.slice(0, 3)), text }); };
    const onError = (error) => done(error);
    function done(error, result) { clearTimeout(timer); socket.off('data', onData); socket.off('error', onError); error ? reject(error) : resolve(result); }
    socket.on('data', onData); socket.on('error', onError);
  });
}
async function command(socket, value, expected) { if (value) socket.write(value + '\r\n'); const reply = await readReply(socket); if (!expected.includes(reply.code)) throw new Error(`SMTP 返回 ${reply.code}`); return reply; }
function encodeHeader(value) { return `=?UTF-8?B?${Buffer.from(String(value)).toString('base64')}?=`; }
function cleanHeader(value) { return String(value || '').replace(/[\r\n]/g, ' ').trim(); }
function waitSecure(socket) { return new Promise((resolve, reject) => { if (socket.authorized) return resolve(); socket.once('secureConnect', resolve); socket.once('error', reject); }); }

export async function sendEmail({ to, subject, text }) {
  const s = await getSystemEmailSettings(true); const host = String(s.smtp_host || '').trim(); const port = Number(s.smtp_port || 465); const secure = String(s.smtp_secure || 'true') !== 'false';
  if (!host || !s.smtp_username || !s.smtp_password) throw new Error('SMTP 尚未完整配置');
  let socket = secure ? tlsConnect({ host, port, servername: host, rejectUnauthorized: true }) : netConnect({ host, port });
  if (secure) await waitSecure(socket);
  await command(socket, '', [220]); await command(socket, `EHLO your-domain.example`, [250]);
  if (!secure) {
    await command(socket, 'STARTTLS', [220]);
    socket = tlsConnect({ socket, servername: host, rejectUnauthorized: true }); await waitSecure(socket);
    await command(socket, `EHLO your-domain.example`, [250]);
  }
  await command(socket, 'AUTH LOGIN', [334]); await command(socket, Buffer.from(s.smtp_username).toString('base64'), [334]); await command(socket, Buffer.from(s.smtp_password).toString('base64'), [235]);
  const fromEmail = cleanHeader(s.smtp_from_email || s.smtp_username); const fromName = cleanHeader(s.smtp_from_name || 'AI 语音助手');
  await command(socket, `MAIL FROM:<${fromEmail}>`, [250]); await command(socket, `RCPT TO:<${to}>`, [250, 251]); await command(socket, 'DATA', [354]);
  const body = String(text).replace(/^\./gm, '..');
  socket.write(`From: ${encodeHeader(fromName)} <${fromEmail}>\r\nTo: <${to}>\r\nSubject: ${encodeHeader(subject)}\r\nDate: ${new Date().toUTCString()}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${Buffer.from(body).toString('base64').match(/.{1,76}/g).join('\r\n')}\r\n.\r\n`);
  await command(socket, '', [250]); await command(socket, 'QUIT', [221]); socket.end(); return true;
}

export async function testEmailSettings(recipient) { await sendEmail({ to: recipient, subject: 'SMTP 测试成功', text: 'AI 语音助手邮件服务连接成功。' }); return true; }

function welcomeText(template, user) {
  const values = { name: user.display_name || user.username, email: user.username, phone: user.phone || '', login_url: process.env.AIAGENT_PUBLIC_URL || 'https://your-domain.example' };
  return String(template).replace(/\{\{(name|email|phone|login_url)\}\}/g, (_all, key) => values[key]);
}

export async function sendWelcomeEmail(user) {
  const settings = await getSystemEmailSettings(false);
  const subject = welcomeText(settings.welcome_subject || '欢迎使用 AI 语音助手', user);
  const body = welcomeText(settings.welcome_body || '您好，{{name}}：\n\n您的 AI 语音助手账户已经开通。\n登录地址：{{login_url}}\n登录邮箱：{{email}}\n\n首次登录后，请按照页面提示连接您的 3CX。', user);
  await sendEmail({ to: user.username, subject, text: body }); return true;
}
