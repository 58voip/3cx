import { createCall, finishCall, getSecretSetting, getSettings, scenarioRuntimeStatus, updateCall } from './store.mjs';
import { resolveQwen } from './model-settings.mjs';
import { createAudioRecorder, createCallLogger } from './call-recordings.mjs';
import { createScenario } from './scenarios/index.mjs';

const clients = new Map();
const statuses = new Map();
const bridges = new Map();
const activeCalls = new Map();
const connectingParticipants = new Set();
const sdkPath = process.env.AIAGENT_3CX_SDK || '@3cx/call-control-sdk';

function tenantKey(userId, id) { return `${userId}:${id}`; }
function setStatus(userId, id, state, message) { statuses.set(tenantKey(userId, id), { state, message, updatedAt: new Date().toISOString() }); }
function callerLanguage(text) { const value = String(text || ''); if ((value.match(/[a-z]/gi) || []).length > Math.max(5, (value.match(/[\u4e00-\u9fff]/g) || []).length)) return 'english'; if (/[喺係唔咗嘅冇佢哋點邊咩喎啦嘛]/.test(value)) return 'cantonese'; return 'mandarin'; }
function configuredVoice(settings, language) { const fallback = { mandarin: 'Tina', cantonese: 'Kiki', english: 'Maia' }[language]; const selected = String(settings[`voices_${language}`] || '').split(/[;；,，\s]+/).map((item) => item.trim()).filter(Boolean)[0]; return selected || fallback; }
function initialVoice(settings) { const selected = String(settings.welcome_voice || '').trim(); if (selected) return selected; const language = String(settings.welcome_language || 'auto'); return configuredVoice(settings, language === 'yue' ? 'cantonese' : language === 'en' ? 'english' : 'mandarin'); }
function welcomeLanguageText(settings) { const language = String(settings.welcome_language || 'auto'); return language === 'yue' ? '欢迎语使用粤语表达。' : language === 'en' ? '欢迎语使用英语表达。' : language === 'zh' ? '欢迎语使用普通话表达。' : '欢迎语先使用普通话；识别到来电者使用其他语言后再切换对应语言。'; }
function callerInfo(participant, ownDn = '') {
  const info = participant?.info || {};
  const own = String(ownDn || info.dn || '').trim();
  const candidates = [info.party_dn, info.party_caller_id, info.originated_by_dn].map(v => String(v || '').trim());
  const number = candidates.find(v => v && v !== own) || '';
  return { name: String(info.party_caller_name || participant?.name || '').trim(), room: number, number };
}

async function stopCall(bindingId) { const call = activeCalls.get(bindingId); if (!call) return; const recordings = call.audioRecorder ? await call.audioRecorder.finalize() : {}; await updateCall(call.id, { transcript: call.transcript || [], caller_audio: recordings.caller || null, assistant_audio: recordings.assistant || null }); await finishCall(call.id); activeCalls.delete(bindingId); }

export async function startThreeCxRuntime(runtimeUser = process.env.AIAGENT_ADMIN_USER || 'configured-user') {
  let CallControlClient; let createQwenRealtimeBridge;
  try { ({ CallControlClient } = await import(sdkPath)); ({ createQwenRealtimeBridge } = await import(process.env.AIAGENT_QWEN_BRIDGE || './providers/qwen-realtime.mjs')); }
  catch (error) { setStatus(runtimeUser, 'realtime', 'unavailable', `3CX/Qwen 运行时不可用：${error instanceof Error ? error.message : String(error)}`); return; }
  const bindings = await scenarioRuntimeStatus(runtimeUser);
  for (const binding of bindings) {
    const bindingKey = tenantKey(runtimeUser, binding.id);
    if (clients.has(bindingKey)) continue;
    if (!binding.configured) { setStatus(runtimeUser, binding.id, 'not_configured', '尚未配置 Client ID'); continue; }
    const settings = await getSettings(binding.id, runtimeUser);
    const apiKey = await getSecretSetting(binding.id, binding.id === 'analysis' ? 'analysis_api_key' : 'threecx_api_key', runtimeUser);
    const server = String(settings.threecx_server || '').trim();
    const clientId = binding.id === 'analysis' ? String(settings.intake_client_id || '') : String(settings.client_id || binding.clientId || '');
    if (!server || !clientId || !apiKey) { setStatus(runtimeUser, binding.id, 'incomplete', '服务器地址、Client ID 或 API Key 未完整配置'); continue; }
    try {
      const client = new CallControlClient({ pbxBase: server, appId: clientId, appSecret: apiKey, websocket: { maxReconnects: Infinity, reconnectDelayMs: 5000, reconnectBackoffMaxMs: 60000 } });
      client.on('connected', () => setStatus(runtimeUser, binding.id, 'connected', '3CX Call Control 已连接'));
      client.on('disconnected', () => setStatus(runtimeUser, binding.id, 'reconnecting', '3CX 连接中断，正在自动重连'));
      client.on('error', (error) => setStatus(runtimeUser, binding.id, 'error', `3CX 连接错误：${error?.message || '未知错误'}`));
      client.on('participantConnected', async (participant) => {
        if (bridges.has(bindingKey) || connectingParticipants.has(bindingKey)) return;
        connectingParticipants.add(bindingKey);
        const caller = callerInfo(participant, clientId);
        const call = await createCall({ scenario: binding.id, caller: caller.name || caller.number || participant?.id || '未知来电', caller_name: caller.name, room_no: caller.room, caller_number: caller.number, callee_name: binding.name, callee_number: clientId, user_id: runtimeUser, workspace_id: 'default' });
        call.transcript = []; call.audioRecorder = createAudioRecorder(call.id); activeCalls.set(bindingKey, call);
        setStatus(runtimeUser, binding.id, 'in_call', `${clientId} 已接入来电，Qwen 正在建立语音会话`);
        const latest = await getSettings(binding.id, runtimeUser);
        const qwen = await resolveQwen(binding.id, runtimeUser);
        let activeLanguage = ''; const logger = createCallLogger(call); let bridge;
        const scenario = createScenario(binding.id, { settings: latest, caller, call, userId: runtimeUser, welcomeLanguageText: welcomeLanguageText(latest), activeLanguage: () => activeLanguage });
        const instructions = scenario.instructions;
        bridge = createQwenRealtimeBridge(participant, {
          apiKey: qwen.apiKey, baseUrl: qwen.baseUrl, model: qwen.model, voice: initialVoice(latest), instructions: instructions.join('\n\n'),
          vadSilenceDurationMs: qwen.source === 'custom' ? qwen.vadSilenceDurationMs : (scenario.vadSilenceDurationMs ?? qwen.vadSilenceDurationMs),
          localTools: scenario.localTools, fileLog: logger, onAudioInput: call.audioRecorder.input, onAudioOutput: call.audioRecorder.output,
          greeting: scenario.greeting, speakOnRouteFailure: false, routeFailureUserReply: '暂时无法完成该操作，请稍后再试。',
          suppressBargeInUntilGreetingDone: true,
          onCallerTranscript: (text) => {
            const mode = String(latest.language_mode || 'auto'); const fixed = { zh: 'mandarin', yue: 'cantonese', en: 'english' }[mode];
            const language = fixed || callerLanguage(text);
            if (language !== activeLanguage) { activeLanguage = language; bridge.setScenario(instructions.join('\n\n'), configuredVoice(latest, language)); setStatus(runtimeUser, binding.id, 'in_call', `${caller.name || '来电'}通话中，已切换${language === 'cantonese' ? '粤语' : language === 'english' ? '英语' : '普通话'}声音`); }
          },
        }, (name, argsJson) => scenario.handleTool(name, argsJson, { bridge: () => bridge, activeLanguage: () => activeLanguage }));
        bridges.set(bindingKey, bridge); connectingParticipants.delete(bindingKey);
      });
      client.on('participantDisconnected', async () => { if (!bridges.has(bindingKey)) return; bridges.get(bindingKey)?.stop(); bridges.delete(bindingKey); connectingParticipants.delete(bindingKey); await stopCall(bindingKey); setStatus(runtimeUser, binding.id, 'connected', '3CX 已连接，当前没有通话'); });
      clients.set(bindingKey, client); setStatus(runtimeUser, binding.id, 'connecting', '正在连接 3CX Call Control'); await client.connect();
    } catch (error) { clients.delete(bindingKey); setStatus(runtimeUser, binding.id, 'error', `3CX 连接失败：${error instanceof Error ? error.message : String(error)}`); }
  }

  // A separate callback broadcaster reads the queued report after aiagent
  // connects to the target extension. It must not reuse the YOUR_ANALYSIS_CLIENT_ID task intake.
  try {
    const analysis = await getSettings('analysis', runtimeUser);
    const appId = String(analysis.notification_client_id || '').trim();
    const appSecret = await getSecretSetting('analysis', 'notification_api_key', runtimeUser);
    const server = String(analysis.threecx_server || '').trim();
    if (!server || !appId || !appSecret) { setStatus(runtimeUser, 'analysis_callback', 'not_configured', '通知结果 API ID 未完整配置'); return; }
    const callbackKey = tenantKey(runtimeUser, 'analysis_callback');
    if (clients.has(callbackKey)) return;
    const callbackClient = new CallControlClient({ pbxBase: server, appId, appSecret, websocket: { maxReconnects: Infinity, reconnectDelayMs: 5000, reconnectBackoffMaxMs: 60000 } });
    callbackClient.on('connected', () => setStatus(runtimeUser, 'analysis_callback', 'connected', '结果播报器已连接'));
    callbackClient.on('error', (error) => setStatus(runtimeUser, 'analysis_callback', 'error', `结果播报器连接错误：${error?.message || '未知错误'}`));
    callbackClient.on('participantConnected', async (participant) => {
      if (bridges.has(callbackKey) || connectingParticipants.has(callbackKey)) return;
      connectingParticipants.add(callbackKey);
      try {
        const { takeAnalysisReport } = await import('./store.mjs');
        const report = await takeAnalysisReport(runtimeUser, 'default');
        if (!report) return;
        const call = await createCall({ scenario: 'analysis', caller: 'aiagent', caller_name: 'aiagent', caller_number: appId, callee_name: '回拨分机', callee_number: report.extension, direction: 'outbound', user_id: report.user_id, workspace_id: report.workspace_id });
        call.transcript = [{ role: 'agent', text: report.report, at: new Date().toISOString() }];
        call.audioRecorder = createAudioRecorder(call.id); activeCalls.set(callbackKey, call);
        const logger = createCallLogger(call);
        const callbackSettings = await getSettings('analysis', report.user_id, report.workspace_id);
        const callbackQwen = await resolveQwen('analysis', report.user_id, report.workspace_id);
        const bridge = createQwenRealtimeBridge(participant, {
          apiKey: callbackQwen.apiKey, baseUrl: callbackQwen.baseUrl, model: callbackQwen.model, voice: String(callbackSettings.callback_voice || (String(callbackSettings.callback_language || 'auto') === 'yue' ? 'Kiki' : String(callbackSettings.callback_language || 'auto') === 'en' ? 'Maia' : 'Tina')),
          instructions: '你正在执行单向语音播报。只播报系统提供的报告正文；不回答问题、不调用工具、不添加欢迎语。播报结束后保持安静。' + ({ zh: '使用普通话播报。', yue: '使用粤语自然表达并播报。', en: '使用英语播报。' }[callbackSettings.callback_language] || '保持报告原有语言。'),
          localTools: [], greeting: report.report, suppressBargeInUntilGreetingDone: true, fileLog: logger, onAudioInput: call.audioRecorder.input, onAudioOutput: call.audioRecorder.output,
          // The provider's remaining duration reflects only buffered 3CX audio and
          // can be too short for a streamed Chinese report. Keep the call alive for
          // a conservative text-based duration so the recipient hears it all.
          onGreetingDone: (remainingMs) => {
            const estimatedMs = Math.min(90000, Math.max(12000, Array.from(String(report.report || '')).length * 240));
            const delayMs = Math.max(Number(remainingMs) || 0, estimatedMs) + 800;
            setTimeout(() => { if (!participant.destroyed) void participant.drop().catch(() => undefined); }, delayMs);
          },
        });
        bridges.set(callbackKey, bridge);
        setStatus(runtimeUser, 'analysis_callback', 'broadcasting', `正在播报任务 ${report.task_id}`);
      } catch (error) {
        setStatus(runtimeUser, 'analysis_callback', 'error', `结果播报失败：${error instanceof Error ? error.message : String(error)}`);
      } finally {
        connectingParticipants.delete(callbackKey);
      }
    });
    callbackClient.on('participantDisconnected', async () => { connectingParticipants.delete(callbackKey); bridges.get(callbackKey)?.stop(); bridges.delete(callbackKey); await stopCall(callbackKey); setStatus(runtimeUser, 'analysis_callback', 'connected', '结果播报器已连接'); });
    clients.set(callbackKey, callbackClient); await callbackClient.connect();
  } catch (error) { clients.delete(tenantKey(runtimeUser, 'analysis_callback')); setStatus(runtimeUser, 'analysis_callback', 'error', `结果播报器启动失败：${error instanceof Error ? error.message : String(error)}`); }
}

export async function stopThreeCxRuntime(userId) {
  const prefix = `${userId}:`;
  for (const [key, bridge] of [...bridges]) if (key.startsWith(prefix)) { bridge?.stop?.(); bridges.delete(key); }
  for (const [key, client] of [...clients]) if (key.startsWith(prefix)) {
    try { if (typeof client.disconnect === 'function') await client.disconnect(); else if (typeof client.close === 'function') await client.close(); }
    catch { /* connection may already be closed */ }
    clients.delete(key); connectingParticipants.delete(key); await stopCall(key);
  }
  for (const key of [...statuses.keys()]) if (key.startsWith(prefix)) statuses.delete(key);
}

export async function reloadThreeCxRuntime(userId) { await stopThreeCxRuntime(userId); await startThreeCxRuntime(userId); }

export function runtimeStatus(userId = process.env.AIAGENT_ADMIN_USER || 'configured-user') { const prefix = `${userId}:`; return Object.fromEntries([...statuses].filter(([key]) => key.startsWith(prefix)).map(([key, value]) => [key.slice(prefix.length), value])); }
