import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { updateCall } from './store.mjs';

const recordingsDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'recordings');

function wav(pcm) {
  const header = Buffer.alloc(44);
  header.write('RIFF', 0); header.writeUInt32LE(36 + pcm.length, 4); header.write('WAVE', 8);
  header.write('fmt ', 12); header.writeUInt32LE(16, 16); header.writeUInt16LE(1, 20); header.writeUInt16LE(1, 22);
  header.writeUInt32LE(8000, 24); header.writeUInt32LE(16000, 28); header.writeUInt16LE(2, 32); header.writeUInt16LE(16, 34);
  header.write('data', 36); header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

export function createAudioRecorder(callId) {
  const caller = [], assistant = [];
  return {
    input: (chunk) => caller.push(Buffer.from(chunk)),
    output: (chunk) => assistant.push(Buffer.from(chunk)),
    async finalize() {
      await mkdir(recordingsDir, { recursive: true });
      const callerFile = `${callId}-caller.wav`, assistantFile = `${callId}-assistant.wav`;
      await writeFile(resolve(recordingsDir, callerFile), wav(Buffer.concat(caller)));
      await writeFile(resolve(recordingsDir, assistantFile), wav(Buffer.concat(assistant)));
      return { caller: `/media/recordings/${callerFile}`, assistant: `/media/recordings/${assistantFile}` };
    },
  };
}

export function createCallLogger(call, base = {}) {
  const noop = () => {};
  return {
    ...base,
    info: base.info || noop, error: base.error || noop, systemPrompt: base.systemPrompt || noop,
    speechEvent: base.speechEvent || noop, toolCalled: base.toolCalled || noop, toolResult: base.toolResult || noop,
    ruleInjected: base.ruleInjected || noop, responseCreated: base.responseCreated || noop, responseDone: base.responseDone || noop,
    transcript(role, text) { if (String(text || '').trim()) { call.transcript.push({ role, text: String(text).trim(), at: new Date().toISOString() }); void updateCall(call.id, { transcript: call.transcript }); } },
  };
}
