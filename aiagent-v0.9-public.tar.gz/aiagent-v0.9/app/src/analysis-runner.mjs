import { callAuthorizedMcpTool, listAuthorizedMcpTools } from './mcp-auth.mjs';
import { getSecretSetting, getSettings, listAllTasks, queueAnalysisReport, updateTask } from './store.mjs';

import { resolveDeepseek } from './model-settings.mjs';
import { customDeepseekOptions } from './model-options.mjs';

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const callbackRetries = new Set();

function mcpActionsFor(task) {
  const intent = `${task.title || ''} ${task.payload?.analysis_target || ''} ${task.payload?.request_text || ''}`.toLowerCase();
  if (/录音|通话|通话记录|通话内容|转写|投诉|情绪|争执/.test(intent)) return ['list_recordings'];
  if (/当前通话|正在通话|活跃通话/.test(intent)) return ['list_active_calls'];
  if (/队列|排队|坐席/.test(intent)) return ['list_queues', 'list_queue_agents'];
  if (/部门|员工|分机|用户/.test(intent)) return ['list_users', 'list_departments'];
  if (/日志|异常|安全|攻击|入侵|漏洞|黑名单|封锁|拦截|鉴权|认证|ip/.test(intent)) return ['list_event_log', 'search_logs', 'list_ip_blocklist'];
  if (/通讯录|联系人|电话簿/.test(intent)) return ['list_phonebook'];
  return ['list_recordings'];
}

function textFromMcp(value) {
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (Array.isArray(value)) return value.map(textFromMcp).join('\n');
  if (value && typeof value === 'object') {
    for (const name of ['text', 'content', 'result', 'message']) {
      if (value[name] !== undefined && value[name] !== value) {
        const text = textFromMcp(value[name]);
        if (text) return text;
      }
    }
    return JSON.stringify(value);
  }
  return '';
}

function compactMcpData(data, maxLength = 12000) {
  const sections = Object.entries(data || {}).map(([tool, value]) => `[${tool}]\n${textFromMcp(value).slice(0, 6000)}`);
  return sections.join('\n\n').slice(0, maxLength);
}

function completionText(payload) {
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content === 'string') return content.trim();
  if (Array.isArray(content)) return content.map((item) => typeof item === 'string' ? item : String(item?.text || item?.content || '')).join('').trim();
  return String(payload?.choices?.[0]?.text || '').trim();
}

async function deepseek(task, data, settings, apiKey) {
  const options = settings.deepseek_config_mode === 'custom' ? customDeepseekOptions(settings) : {
    baseUrl: String(settings.deepseek_base_url || 'https://your-deepseek-endpoint.example').replace(/\/$/, ''),
    model: String(settings.deepseek_model || 'deepseek-v4-flash'), temperature: 0.2, maxTokens: 1200, timeoutMs: 90000,
  };
  const base = options.baseUrl;
  const model = options.model;
  const maxChars = Math.min(1000, Math.max(50, Number(settings.callback_max_chars) || 180));
  const reportLanguage = { zh: '普通话', yue: '粤语', en: '英语', mandarin: '普通话', cantonese: '粤语', english: '英语' }[settings.callback_language === 'auto' || !settings.callback_language ? task.payload.language : settings.callback_language] || '来电者使用的语言，未知时使用普通话';
  const callbackPrompt = String(settings.callback_prompt || '先说明分析已完成，再用简洁口语播报最重要的结论和建议；不要标题、编号或重复任务内容。').trim();
  const prompt = `分析任务：${task.title}\n对象：${task.payload.employee || '未指定'}\n部门：${task.payload.department || '未指定'}\n时间：${task.payload.period || '未指定'}\n目标：${task.payload.analysis_target || '通话内容总结'}\n\n3CX MCP 返回数据：\n${compactMcpData(data)}`;
  const request = async (maxTokens) => fetch(`${base}/chat/completions`, { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model, temperature: options.temperature, max_tokens: maxTokens, messages: [
    { role: 'system', content: `你是语音分析助手。只能依据 3CX MCP 返回的数据回答，不得编造。此内容将被电话直接播报。使用${reportLanguage}。回拨回复要求：${callbackPrompt}\n必须是自然、简洁、可直接朗读的一段话；不使用标题、编号、Markdown 或“关键证据”等栏目名称；总长度不超过 ${maxChars} 个汉字或字符。` },
    { role: 'user', content: prompt },
  ] }), signal: AbortSignal.timeout(options.timeoutMs) });
  let response = await request(options.maxTokens);
  if (!response.ok) throw new Error(`DeepSeek HTTP ${response.status}`);
  let payload = await response.json();
  let answer = completionText(payload);
  if (!answer) {
    response = await request(settings.deepseek_config_mode === 'custom' ? options.maxTokens : 4096);
    if (!response.ok) throw new Error(`DeepSeek HTTP ${response.status}`);
    payload = await response.json();
    answer = completionText(payload);
  }
  if (!answer) {
    const choice = payload?.choices?.[0] || {};
    console.warn('[Analysis] DeepSeek returned no usable content', JSON.stringify({ model, finish_reason: choice.finish_reason || null, message_keys: Object.keys(choice.message || {}) }));
    throw new Error('DeepSeek 返回内容为空');
  }
  return limitCallbackText(answer, maxChars);
}

function limitCallbackText(value, maxChars) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  if (text.length <= maxChars) return text;
  const slice = text.slice(0, maxChars);
  const boundary = Math.max(slice.lastIndexOf('。'), slice.lastIndexOf('！'), slice.lastIndexOf('？'));
  return (boundary >= Math.floor(maxChars * 0.6) ? slice.slice(0, boundary + 1) : slice).trim();
}

function fallbackReport(task, data, error) {
  const entries = Object.entries(data || {});
  const successful = entries.filter(([, value]) => !(value && typeof value === 'object' && value.isError)).map(([name]) => name);
  const failed = entries.filter(([, value]) => value && typeof value === 'object' && value.isError).length;
  return `查询已完成。${successful.length ? `已获取${successful.length}项 3CX 数据。` : ''}${failed ? '部分数据暂时无法读取。' : ''}暂时无法生成语音摘要，请稍后重新查询。`;
}

async function callNotification(task, report, userId, workspaceId) {
  const settings = await getSettings('analysis', userId, workspaceId);
  const appId = String(settings.notification_client_id || '').trim();
  const secret = await getSecretSetting('analysis', 'notification_api_key', userId, workspaceId);
  const base = String(settings.threecx_server || '').replace(/\/$/, '');
  const destination = String(task.payload.callback_extension || task.payload.caller_extension || task.payload.caller_number || '').trim();
  if (!appId || !secret || !base) throw new Error('通知结果 3CX API ID 尚未完整配置');
  if (!/^\d+$/.test(destination) || destination === appId) throw new Error('没有可用的通知回拨分机');
  const tokenResponse = await fetch(`${base}/connect/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'client_credentials', client_id: appId, client_secret: secret }), signal: AbortSignal.timeout(15000) });
  if (!tokenResponse.ok) throw new Error(`通知连接鉴权失败（HTTP ${tokenResponse.status}）`);
  const token = String((await tokenResponse.json()).access_token || '');
  const response = await fetch(`${base}/callcontrol/${encodeURIComponent(appId)}/makecall`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ destination, timeout: 180, metadata: { task_id: task.id, report: report.slice(0, 3000) } }), signal: AbortSignal.timeout(20000) });
  const body = await response.text();
  if (!response.ok) throw new Error(`通知回拨失败（HTTP ${response.status}）：${body.slice(0, 240)}`);
  return { appId, destination };
}

export async function retryAnalysisCallback(task) {
  if (!task?.id || task.scenario !== 'analysis') throw new Error('分析任务不存在');
  if (!String(task.result || '').trim()) throw new Error('该任务尚未生成可播报的分析结果');
  if (callbackRetries.has(task.id)) throw new Error('该任务正在回拨，请勿重复操作');
  callbackRetries.add(task.id);
  try {
    const callbackTarget = String(task.payload?.callback_extension || task.payload?.caller_extension || task.payload?.caller_number || '').trim();
    await queueAnalysisReport(task.id, callbackTarget, task.result, task.user_id, task.workspace_id);
    await updateTask(task.id, { callback_status: 'waiting', callback_extension: callbackTarget });
    const callback = await callNotification(task, task.result, task.user_id, task.workspace_id);
    await updateTask(task.id, { callback_status: 'sent', callback: { ...callback, sent_at: new Date().toISOString() } });
    return callback;
  } catch (error) {
    await updateTask(task.id, { callback_status: 'failed', callback_error: error instanceof Error ? error.message : String(error) });
    throw error;
  } finally {
    callbackRetries.delete(task.id);
  }
}

async function processTask(task) {
  await updateTask(task.id, { status: 'analyzing', analysis_status: 'running', mcp_status: 'pending' });
  try {
    const settings = await getSettings('analysis', task.user_id, task.workspace_id);
    const tools = await listAuthorizedMcpTools('analysis', undefined, task.user_id, task.workspace_id);
    const configured = String(settings.mcp_tools || '').split(',').map((item) => item.trim()).filter(Boolean);
    // Analysis is strictly read-only. Never execute an arbitrary discovered MCP
    // tool: 3CX also exposes call-control and configuration mutation tools.
    const safeDefaults = new Set(['list_recordings', 'list_call_records', 'list_call_logs', 'list_users', 'list_departments', 'list_active_calls', 'get_server_time', 'list_queues', 'list_queue_agents', 'search_logs', 'list_event_log', 'list_ip_blocklist', 'list_phonebook']);
    const enabled = new Set(configured.length ? configured.filter((name) => safeDefaults.has(name)) : [...safeDefaults]);
    const candidates = mcpActionsFor(task).filter((name) => enabled.has(name));
    const selected = tools.filter((tool) => candidates.includes(tool.name) && safeDefaults.has(tool.name));
    if (!selected.length) throw new Error('MCP 已授权，但没有启用可用工具');
    const data = {};
    for (const tool of selected.slice(0, 8)) {
      const args = tool.name === 'list_recordings' || tool.name === 'list_call_records' || tool.name === 'list_call_logs'
        ? { maxResults: 200, employee: task.payload.employee || '', department: task.payload.department || '', period: task.payload.period || '' }
        : tool.name === 'search_logs' ? { pattern: '(security|attack|unauthorized|failed|block|denied|authentication|auth)', maxResults: 200, contextLines: 1 }
        : tool.name === 'list_event_log' ? { type: 'Error', maxResults: 200 }
        : tool.name === 'list_phonebook' ? { query: ' ', searchExtensions: true, searchCompany: true, searchPersonal: true, searchGroup: true, maxResults: 1000 }
          : { maxResults: 200 };
      try { data[tool.name] = await callAuthorizedMcpTool('analysis', tool.name, args, task.user_id, task.workspace_id); }
      catch (error) { data[tool.name] = { isError: true, error: error instanceof Error ? error.message : String(error) }; }
    }
    await updateTask(task.id, { mcp_status: 'completed', mcp_tools_used: selected.map((tool) => tool.name) });
    const apiKey = await resolveDeepseek(task.user_id, task.workspace_id);
    if (!apiKey) throw new Error('DeepSeek API 尚未配置');
    let report;
    let modelStatus = 'completed';
    let modelError = '';
    try { report = await deepseek(task, data, settings, apiKey); }
    catch (error) { report = limitCallbackText(fallbackReport(task, data, error), Math.min(1000, Math.max(50, Number(settings.callback_max_chars) || 180))); modelStatus = 'fallback'; modelError = error instanceof Error ? error.message : String(error); }
    await updateTask(task.id, { status: 'completed', analysis_status: 'completed', model_status: modelStatus, model_error: modelError, result: report, completed_at: new Date().toISOString() });
    try {
      const callbackTarget = String(task.payload.callback_extension || task.payload.caller_extension || task.payload.caller_number || '').trim();
      await queueAnalysisReport(task.id, callbackTarget, report, task.user_id, task.workspace_id);
      await updateTask(task.id, { callback_status: 'waiting', callback_extension: callbackTarget });
      const callback = await callNotification(task, report, task.user_id, task.workspace_id);
      await updateTask(task.id, { callback_status: 'sent', callback: { ...callback, sent_at: new Date().toISOString() } });
    } catch (error) {
      await updateTask(task.id, { callback_status: 'failed', callback_error: error instanceof Error ? error.message : String(error) });
    }
  } catch (error) {
    await updateTask(task.id, { status: 'failed', analysis_status: 'failed', mcp_status: 'failed', error: error instanceof Error ? error.message : String(error) });
  }
}

export async function startAnalysisRunner() {
  let running = false;
  while (true) {
    if (!running) {
      running = true;
      try {
        const tasks = (await listAllTasks('analysis')).filter((task) => task.status === 'created');
        for (const task of tasks.slice(0, 2)) await processTask(task);
      } catch (error) { console.warn(`[analysis-runner] ${error instanceof Error ? error.message : error}`); }
      finally { running = false; }
    }
    await wait(5000);
  }
}
