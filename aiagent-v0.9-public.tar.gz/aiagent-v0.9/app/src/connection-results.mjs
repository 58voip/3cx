import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, writeFile, unlink } from 'node:fs/promises';
import { resolve } from 'node:path';

export const RESULT_MAX_AGE_MS = 24 * 60 * 60 * 1000;
export function resultStore(directory = process.env.AIAGENT_CONNECTION_RESULTS_DIR || new URL('../data/connection-results/', import.meta.url).pathname) {
  const pathFor = key => resolve(directory, createHash('sha256').update(key).digest('hex') + '.json');
  return {
    async read(key) {
      try { return JSON.parse(await readFile(pathFor(key), 'utf8')); }
      catch (error) { if (error.code === 'ENOENT' || error instanceof SyntaxError) return null; throw error; }
    },
    async save(key, entry) {
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const target = pathFor(key), temporary = target + '.' + randomUUID() + '.tmp';
      try { await writeFile(temporary, JSON.stringify(entry), { mode: 0o600, flag: 'wx' }); await rename(temporary, target); }
      finally { await unlink(temporary).catch(() => {}); }
    },
  };
}
export function visibleResult(prior, fingerprint, configured, now = Date.now()) {
  if (!configured) return { state: 'empty', message: '未填写' };
  if (!prior || prior.fingerprint !== fingerprint) return { state: 'untested', message: prior ? '配置已修改，待测试' : '已配置，未测试' };
  if (now - prior.at >= RESULT_MAX_AGE_MS) return { ...prior.result, state: 'stale', lastState: prior.result.state, message: '待复测 · 上次' + (prior.result.state === 'success' ? '成功' : '失败') };
  return { ...prior.result, expiresAt: new Date(prior.at + RESULT_MAX_AGE_MS).toISOString() };
}
