// Public release supports token-based MCP configuration only.
// OAuth registration, token persistence, and account fallback are omitted.
export async function beginMcpOAuth() { throw new Error('公开版本不包含 MCP OAuth；请在 MCP 设置中使用访问令牌'); }
export async function finishMcpOAuth() { throw new Error('公开版本不包含 MCP OAuth；请在 MCP 设置中使用访问令牌'); }
export function oauthPending() { return []; }
export async function listAuthorizedMcpTools() { throw new Error('公开版本不包含 MCP OAuth；请在 MCP 设置中使用访问令牌'); }
export async function callAuthorizedMcpTool() { throw new Error('公开版本不包含 MCP OAuth；请在 MCP 设置中使用访问令牌'); }
export async function migrateMcpIdentity() {}
