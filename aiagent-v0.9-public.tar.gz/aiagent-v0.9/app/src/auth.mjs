import { createHash, randomBytes, randomInt, scryptSync, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync, readFileSync, writeFileSync, chmodSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sendEmail } from './email.mjs';

const dataDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'data');
const usersFile = resolve(dataDir, 'users.json');
const sessionsFile = resolve(dataDir, 'sessions.json');
const sessions = new Map();
const emailCodes = new Map();
const emailChangeCodes = new Map();
const defaultUser = process.env.AIAGENT_ADMIN_USER || 'configured-user';
// A deployment must provide the initial administrator password explicitly.
// Never keep a usable password in the source tree or public repository.
const defaultPassword = process.env.AIAGENT_ADMIN_PASSWORD || randomBytes(32).toString('base64url');

try {
  const stored = JSON.parse(readFileSync(sessionsFile, 'utf8'));
  for (const [token, session] of Object.entries(stored)) if (session.expiresAt > Date.now()) sessions.set(token, session);
} catch { /* first start */ }

function persistSessions() {
  mkdirSync(dataDir, { recursive: true });
  writeFileSync(sessionsFile, JSON.stringify(Object.fromEntries(sessions)), { mode: 0o600 });
  chmodSync(sessionsFile, 0o600);
}

function hash(password, salt = randomBytes(16).toString('hex')) {
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}

function matches(password, stored) {
  try {
    const [salt, expected] = String(stored).split(':');
    const actual = scryptSync(password, salt, 64);
    return timingSafeEqual(actual, Buffer.from(expected, 'hex'));
  } catch { return false; }
}

async function users() {
  if (existsSync(usersFile)) {
    try {
      const stored = JSON.parse(await readFile(usersFile, 'utf8'));
      // Migrate the initial bootstrap account to the owner's requested login name.
      if (defaultUser !== 'admin' && stored.length === 1 && stored[0].username === 'admin') {
        stored[0].username = defaultUser;
        await writeFile(usersFile, JSON.stringify(stored, null, 2) + '\n', { mode: 0o600 });
      }
      return stored;
    } catch { /* rebuild below */ }
  }
  const initial = [{ username: defaultUser, display_name: '管理员', password_hash: hash(defaultPassword), role: 'admin', active: true, must_change_password: false, created_at: new Date().toISOString() }];
  await mkdir(dataDir, { recursive: true });
  await writeFile(usersFile, JSON.stringify(initial, null, 2) + '\n', { mode: 0o600 });
  return initial;
}

export async function login(username, password) {
  const user = (await users()).find((item) => item.username === String(username || '').trim());
  if (!user || user.active === false || !matches(String(password || ''), user.password_hash)) return null;
  return createSession(user);
}

function createSession(user) {
  const token = randomBytes(32).toString('base64url');
  sessions.set(token, { userId: user.username, workspaceId: user.workspace_id || 'default', role: user.role, displayName: user.display_name || user.username, mustChangePassword: Boolean(user.must_change_password), expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
  persistSessions(); return { token, user: { username: user.username, role: user.role, mustChangePassword: Boolean(user.must_change_password) } };
}

function codeHash(username, code) { return createHash('sha256').update(`${username}:${code}`).digest('hex'); }

export async function requestEmailCode(username) {
  const email = String(username || '').trim().toLowerCase(); const now = Date.now(); const prior = emailCodes.get(email);
  if (prior?.sentAt && now - prior.sentAt < 60_000) throw new Error('验证码发送过于频繁，请稍后再试');
  const user = (await users()).find((item) => item.username.toLowerCase() === email && item.active !== false);
  if (!user) return true;
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  emailCodes.set(email, { hash: codeHash(email, code), expiresAt: now + 10 * 60_000, attempts: 0, sentAt: now });
  try { await sendEmail({ to: email, subject: 'AI 语音助手登录验证码', text: `您的登录验证码是：${code}\n\n验证码 10 分钟内有效，请勿转发。` }); }
  catch (error) { emailCodes.delete(email); throw error; }
  return true;
}

export async function loginWithEmailCode(username, code) {
  const email = String(username || '').trim().toLowerCase(); const item = emailCodes.get(email);
  if (!item || item.expiresAt < Date.now() || item.attempts >= 5) { emailCodes.delete(email); return null; }
  item.attempts += 1;
  const actual = Buffer.from(codeHash(email, String(code || '').trim()), 'hex'); const expected = Buffer.from(item.hash, 'hex');
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return null;
  const user = (await users()).find((entry) => entry.username.toLowerCase() === email && entry.active !== false);
  if (!user) return null; emailCodes.delete(email); return createSession(user);
}

function publicUser(user) {
  return { username: user.username, display_name: user.display_name || '', phone: user.phone || '', role: user.role || 'user', active: user.active !== false, pending_approval: Boolean(user.pending_approval), must_change_password: Boolean(user.must_change_password), created_at: user.created_at || null, approved_at: user.approved_at || null, updated_at: user.updated_at || null };
}

function validPhone(value) { return /^\+?[0-9][0-9 ()-]{6,19}$/.test(String(value || '').trim()); }

async function saveUsers(items) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(usersFile, JSON.stringify(items, null, 2) + '\n', { mode: 0o600 });
}

export async function listUsers() { return (await users()).map(publicUser); }
export async function getUser(userId) { const user = (await users()).find((item) => item.username === userId); return user ? publicUser(user) : null; }

export async function createUser(input = {}) {
  const username = String(input.username || '').trim().toLowerCase();
  const password = String(input.password || '');
  const phone = String(input.phone || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) throw new Error('请输入有效的邮箱地址');
  if (!validPhone(phone)) throw new Error('请输入有效的手机号码');
  if (password.length < 10) throw new Error('临时密码至少需要 10 个字符');
  const items = await users();
  if (items.some((item) => item.username.toLowerCase() === username)) throw new Error('用户已存在');
  const now = new Date().toISOString();
  const user = { username, display_name: String(input.display_name || '').trim(), phone, password_hash: hash(password), role: 'user', active: true, pending_approval: false, must_change_password: true, workspace_id: 'default', created_at: now, approved_at: now, updated_at: now };
  items.push(user); await saveUsers(items); return publicUser(user);
}

export async function registerUser(input = {}) {
  const username = String(input.username || '').trim().toLowerCase(); const password = String(input.password || ''); const phone = String(input.phone || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) throw new Error('请输入有效的邮箱地址');
  if (!validPhone(phone)) throw new Error('请输入有效的手机号码');
  if (password.length < 10) throw new Error('密码至少需要 10 个字符');
  const items = await users(); if (items.some((item) => item.username.toLowerCase() === username)) throw new Error('该邮箱已经注册或正在审批');
  const now = new Date().toISOString(); const user = { username, display_name: String(input.display_name || '').trim(), phone, password_hash: hash(password), role: 'user', active: false, pending_approval: true, must_change_password: false, workspace_id: 'default', created_at: now, updated_at: now };
  items.push(user); await saveUsers(items); return publicUser(user);
}

export async function approveUser(username) {
  const items = await users(); const user = items.find((item) => item.username === username);
  if (!user || !user.pending_approval) throw new Error('没有找到待审批用户');
  const now = new Date().toISOString(); user.pending_approval = false; user.active = true; user.approved_at = now; user.updated_at = now; await saveUsers(items); return publicUser(user);
}

export async function updateUser(username, input = {}) {
  const items = await users(); const user = items.find((item) => item.username === username);
  if (!user) throw new Error('用户不存在');
  if (user.role === 'admin' && input.active === false) throw new Error('不能停用管理员账户');
  if (input.display_name !== undefined) user.display_name = String(input.display_name).trim();
  if (input.phone !== undefined) { if (!validPhone(input.phone)) throw new Error('请输入有效的手机号码'); user.phone = String(input.phone).trim(); }
  if (input.active !== undefined) user.active = Boolean(input.active);
  if (input.password) { if (String(input.password).length < 10) throw new Error('密码至少需要 10 个字符'); user.password_hash = hash(String(input.password)); user.must_change_password = Boolean(input.must_change_password ?? true); }
  user.updated_at = new Date().toISOString(); await saveUsers(items);
  if (user.active === false) { for (const [token, session] of sessions) if (session.userId === username) sessions.delete(token); persistSessions(); }
  return publicUser(user);
}

export async function changePassword(userId, currentPassword, nextPassword) {
  if (String(nextPassword || '').length < 10) throw new Error('新密码至少需要 10 个字符');
  const items = await users(); const user = items.find((item) => item.username === userId);
  if (!user || !matches(String(currentPassword || ''), user.password_hash)) throw new Error('当前密码不正确');
  user.password_hash = hash(String(nextPassword)); user.must_change_password = false; user.updated_at = new Date().toISOString(); await saveUsers(items);
  for (const session of sessions.values()) if (session.userId === userId) session.mustChangePassword = false;
  persistSessions(); return true;
}

export async function updateProfile(userId, input = {}) {
  const items = await users(); const user = items.find((item) => item.username === userId);
  if (!user) throw new Error('用户不存在');
  if (input.phone !== undefined && !validPhone(input.phone)) throw new Error('请输入有效的手机号码');
  if (input.display_name !== undefined) user.display_name = String(input.display_name).trim();
  if (input.phone !== undefined) user.phone = String(input.phone).trim();
  user.updated_at = new Date().toISOString(); await saveUsers(items);
  for (const session of sessions.values()) if (session.userId === userId) session.displayName = user.display_name || user.username;
  persistSessions(); return publicUser(user);
}

export async function requestEmailChange(userId, nextEmail) {
  const email = String(nextEmail || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('请输入有效的新邮箱地址');
  const items = await users(); if (items.some((item) => item.username.toLowerCase() === email)) throw new Error('该邮箱已经被使用');
  const now = Date.now(); const prior = emailChangeCodes.get(userId); if (prior?.sentAt && now - prior.sentAt < 60_000) throw new Error('验证码发送过于频繁，请稍后再试');
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  emailChangeCodes.set(userId, { email, hash: codeHash(email, code), expiresAt: now + 10 * 60_000, attempts: 0, sentAt: now });
  try { await sendEmail({ to: email, subject: '确认新的登录邮箱', text: `您的邮箱验证码是：${code}\n\n验证码 10 分钟内有效。` }); }
  catch (error) { emailChangeCodes.delete(userId); throw error; }
  return true;
}

export async function confirmEmailChange(userId, nextEmail, code) {
  const email = String(nextEmail || '').trim().toLowerCase(); const item = emailChangeCodes.get(userId);
  if (!item || item.email !== email || item.expiresAt < Date.now() || item.attempts >= 5) { emailChangeCodes.delete(userId); throw new Error('验证码错误或已过期'); }
  item.attempts += 1; const actual = Buffer.from(codeHash(email, String(code || '').trim()), 'hex'); const expected = Buffer.from(item.hash, 'hex');
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) throw new Error('验证码错误或已过期');
  const items = await users(); if (items.some((entry) => entry.username.toLowerCase() === email)) throw new Error('该邮箱已经被使用');
  const user = items.find((entry) => entry.username === userId); if (!user) throw new Error('用户不存在');
  user.username = email; user.updated_at = new Date().toISOString(); await saveUsers(items);
  for (const session of sessions.values()) if (session.userId === userId) { session.userId = email; session.displayName = user.display_name || email; }
  persistSessions(); emailChangeCodes.delete(userId); return { previous: userId, user: publicUser(user) };
}

export function sessionFrom(req) {
  const header = String(req.headers.cookie || '').split(';').map((item) => item.trim()).find((item) => item.startsWith('aiagent_session='));
  if (!header) return null;
  const token = decodeURIComponent(header.slice('aiagent_session='.length));
  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) { sessions.delete(token); persistSessions(); return null; }
  return session;
}

export function logout(req) {
  const sessionCookie = String(req.headers.cookie || '').split(';').map((item) => item.trim()).find((item) => item.startsWith('aiagent_session='));
  if (sessionCookie) { sessions.delete(decodeURIComponent(sessionCookie.slice('aiagent_session='.length))); persistSessions(); }
}

export function loginPage(message = '') {
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>登录 · AI 语音助手</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1422;color:#e8eef7;font-family:Inter,system-ui,-apple-system,sans-serif}.card{width:min(410px,calc(100% - 36px));padding:30px;background:#101f33;border:1px solid #29415f;border-radius:16px;box-shadow:0 20px 60px #02081288}h1{margin:0 0 18px;font-size:24px}.tabs{display:flex;gap:8px;margin-bottom:18px}.tab{width:auto;background:#14243a;color:#91a7c1;border:1px solid #304966}.tab.active{background:#2b6ff2;color:#fff;border-color:#2b6ff2}.field{display:grid;gap:7px;margin:16px 0}.field label{font-size:12px;color:#92a8c2}input{width:100%;padding:11px;border:1px solid #304966;border-radius:8px;background:#0b1728;color:#fff;box-sizing:border-box}button{width:100%;padding:11px;border:0;border-radius:8px;background:#2b6ff2;color:#fff;cursor:pointer;font-size:14px}.code{display:grid;grid-template-columns:1fr 120px;gap:8px}.secondary{background:#193655}.error{color:#ff9b9b;min-height:20px;font-size:13px}.hidden{display:none}</style></head><body><main class="card"><h1>AI 语音助手</h1><div class="tabs"><button class="tab active" data-mode="code">邮箱验证码</button><button class="tab" data-mode="password">密码登录</button></div><section id="codePanel"><div class="field"><label>邮箱</label><input id="email" type="email" autocomplete="username"></div><div class="field"><label>验证码</label><div class="code"><input id="code" inputmode="numeric" maxlength="6"><button id="send" class="secondary">发送验证码</button></div></div><button id="codeLogin">登录</button></section><form id="passwordPanel" class="hidden" method="post" action="/api/auth/login"><div class="field"><label>邮箱</label><input name="username" type="email" autocomplete="username" required></div><div class="field"><label>密码</label><input name="password" type="password" autocomplete="current-password" required></div><button type="submit">登录</button></form><div class="error" id="message">${message}</div></main><script>const message=document.getElementById('message');document.querySelectorAll('[data-mode]').forEach(button=>button.onclick=()=>{document.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('active',x===button));document.getElementById('codePanel').classList.toggle('hidden',button.dataset.mode!=='code');document.getElementById('passwordPanel').classList.toggle('hidden',button.dataset.mode!=='password')});document.getElementById('send').onclick=async()=>{const button=document.getElementById('send'),username=document.getElementById('email').value;button.disabled=true;try{const response=await fetch('/api/auth/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})}),result=await response.json();message.textContent=result.message||result.error||'';if(response.ok){let left=60;button.textContent=left+'秒';const timer=setInterval(()=>{left--;button.textContent=left+'秒';if(left<=0){clearInterval(timer);button.disabled=false;button.textContent='发送验证码'}},1000)}else button.disabled=false}catch(error){message.textContent='发送失败，请稍后再试';button.disabled=false}};document.getElementById('codeLogin').onclick=async()=>{const response=await fetch('/api/auth/email/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:document.getElementById('email').value,code:document.getElementById('code').value})}),result=await response.json();if(!response.ok){message.textContent=result.error||'登录失败';return}location.href=result.redirect||'/'}</script></body></html>`;
}
