export function modelBaseUrl(value, provider) {
  const raw = String(value || '').trim();
  let url;
  try { url = new URL(raw.replace(/^wss:/, 'https:')); } catch { throw new Error(provider + ' 服务器地址格式不正确'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw new Error(provider + ' 地址须使用 HTTPS，且不能包含账号、查询参数或密钥');
  let path = url.pathname.replace(/\/+$/, '');
  if (provider === 'Qwen') {
    path = path.replace(/\/api-ws\/v1\/realtime$/, '');
    if (path) throw new Error('Qwen 请填写服务器根地址，或完整的 /api-ws/v1/realtime 地址');
  } else {
    path = path.replace(/\/chat\/completions$/, '');
  }
  return url.origin + path;
}

function numberOption(value, fallback, min, max, label, integer = false) {
  const number = value === undefined || value === '' ? fallback : Number(value);
  if (!Number.isFinite(number) || number < min || number > max || (integer && !Number.isInteger(number))) throw new Error(label + '须在 ' + min + '–' + max + ' 之间' + (integer ? '，并使用整数' : ''));
  return number;
}

function modelName(value, fallback) {
  const name = String(value || fallback).trim();
  if (!name || name.length > 160 || /\s/.test(name)) throw new Error('模型名称不能为空或包含空格');
  return name;
}

export function customQwenOptions(settings) {
  let address = settings.custom_qwen_base_url || 'https://your-qwen-endpoint.example';
  if (settings.custom_qwen_region && settings.custom_qwen_region !== 'manual') {
    if (!['cn-beijing', 'ap-southeast-1'].includes(settings.custom_qwen_region)) throw new Error('请选择有效的 Qwen 地域');
    const workspace = String(settings.custom_qwen_workspace_id || '').trim();
    if (!/^[a-zA-Z0-9][a-zA-Z0-9-]{0,99}$/.test(workspace)) throw new Error('请填写有效的阿里云工作空间 ID');
    address = `https://${workspace}.${settings.custom_qwen_region}.maas.aliyuncs.com`;
  }
  return {
    baseUrl: modelBaseUrl(address, 'Qwen'),
    model: modelName(settings.custom_qwen_model, 'qwen3.5-omni-plus-realtime'),
    vadSilenceDurationMs: numberOption(settings.custom_qwen_vad_ms, 2400, 200, 5000, '语音停顿等待时间', true),
  };
}

export function customDeepseekOptions(settings) {
  return {
    baseUrl: modelBaseUrl(settings.custom_deepseek_base_url || 'https://your-deepseek-endpoint.example', 'DeepSeek'),
    model: modelName(settings.custom_deepseek_model, 'deepseek-v4-flash'),
    temperature: numberOption(settings.custom_deepseek_temperature, 0.2, 0, 2, '温度'),
    maxTokens: numberOption(settings.custom_deepseek_max_tokens, 4096, 256, 32768, '最大输出 Token', true),
    timeoutMs: numberOption(settings.custom_deepseek_timeout_seconds, 90, 10, 180, '请求超时秒数', true) * 1000,
  };
}
