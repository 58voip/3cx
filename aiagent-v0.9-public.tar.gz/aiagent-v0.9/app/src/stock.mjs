import { getSecretSetting, getSettings } from './store.mjs';
import { reserveStockSlot } from './stock-quota.mjs';

const sdkPath = process.env.AIAGENT_MCP_SDK || '@modelcontextprotocol/sdk';
const aliases = { '特斯拉': 'TSLA', '苹果': 'AAPL', '亚马逊': 'AMZN', Amazon: 'AMZN', amazon: 'AMZN', AWS: 'AMZN', aws: 'AMZN', '英伟达': 'NVDA', '微软': 'MSFT', '谷歌': 'GOOGL', '阿里巴巴': 'BABA', '腾讯': 'TCEHY', '奈飞': 'NFLX', '波音': 'BA', Boeing: 'BA', boeing: 'BA' };

async function stockToken(userId, workspaceId) {
  return await getSecretSetting('realtime', 'stock_mcp_token', userId, workspaceId) || process.env.AIAGENT_DEMO_STOCK_TOKEN || '';
}
export function isStockAuthError(error) { return /401|403|invalid[_ ]?token|authentication required|unauthorized/i.test(String(error?.message || error)); }

async function connect(endpoint, token, name = 'aiagent-stock-demo') {
  const [{ Client }, { StreamableHTTPClientTransport }] = await Promise.all([import(`${sdkPath}/client/index.js`), import(`${sdkPath}/client/streamableHttp.js`)]);
  const transport = new StreamableHTTPClientTransport(new URL(endpoint), { requestInit: { headers: { Authorization: `Bearer ${token}` } } });
  const client = new Client({ name, version: '1.0.0' }, { capabilities: {} });
  try { await client.connect(transport); return client; } catch (error) { await client.close().catch(() => {}); throw error; }
}

export async function testStockMcpConnection(userId, workspaceId = 'default') {
  const settings = await getSettings('realtime', userId, workspaceId);
  const endpoint = String(settings.stock_mcp_url || 'https://mcp.twelvedata.com/mcp');
  const token = await stockToken(userId, workspaceId);
  if (!token) throw new Error('股票演示许可未配置');
  const client = await connect(endpoint, token, 'aiagent-stock-demo-test');
  try { return (await client.listTools()).tools || []; } finally { await client.close().catch(() => {}); }
}

function symbols(value) { return [...new Set(String(value || '').split(/[,，、/\s]+/).map(item => item.trim()).filter(Boolean).map(item => aliases[item] || item.toUpperCase()))]; }

export async function queryStock(value, userId, workspaceId = 'default', onWait) {
  const list = symbols(value); if (!list.length) throw new Error('请说出股票名称或代码');
  const token = await stockToken(userId, workspaceId); if (!token) throw new Error('股票演示许可未配置');
  const settings = await getSettings('realtime', userId, workspaceId);
  const endpoint = String(settings.stock_mcp_url || 'https://mcp.twelvedata.com/mcp');
  const client = await connect(endpoint, token);
  try {
    const results = [];
    for (const symbol of list) {
      await reserveStockSlot(onWait);
      const result = await client.callTool({ name: 'get_quote', arguments: { symbol } });
      const text = (result.content || []).filter(item => item.type === 'text').map(item => item.text || '').join('\n');
      results.push(`${symbol}: ${text || '未返回行情'}`);
    }
    return results.join('\n');
  } finally { await client.close().catch(() => undefined); }
}
