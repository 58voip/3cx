// Public origin is explicit: never trust a caller-supplied X-Forwarded-Host.
export function connectionOriginAllowed(origin, host, publicOrigin = process.env.AIAGENT_PUBLIC_ORIGIN || 'https://your-domain.example') {
  if (!origin) return true; // Non-browser clients still require a valid login session.
  try {
    const source = new URL(origin);
    if (!['http:', 'https:'].includes(source.protocol) || source.username || source.password || source.pathname !== '/' || source.search || source.hash) return false;
    return source.origin === new URL(publicOrigin).origin || source.host === host;
  } catch { return false; }
}
