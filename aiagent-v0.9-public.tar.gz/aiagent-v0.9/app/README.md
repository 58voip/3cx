# AI Agent 0.9

This is a sanitized reference release of a Node.js voice assistant.

Included:
- realtime voice assistant
- voice task creation
- voice analysis and callback workflow
- multi-user account isolation
- configurable 3CX, MCP, Qwen and DeepSeek adapters

Before deployment, provide your own credentials and service addresses through environment variables and the application settings. No production accounts, IDs, secrets, tokens, OAuth grants, call records, transcripts, recordings, or user data are included.

The demo behavior is configuration-driven. Replace all placeholder values with your own tenant-specific settings.
