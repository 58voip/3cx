# AI Agent 0.9

Sanitized reference release for a Node.js AI voice assistant.

The release includes realtime voice, voice task creation, voice analysis, callback workflows, and multi-user isolation. Integrations are configuration-driven: each deployment supplies its own 3CX IDs, MCP settings, and model credentials.

No production IDs, API keys, MCP tokens, OAuth grants, user data, calls, transcripts, recordings, or credentials are included.
